import { motion } from "framer-motion";
import { CheckCircle2, AlertCircle } from "lucide-react";

interface SkillCardProps {
  name: string;
  level: "strong" | "moderate" | "missing";
  category: string;
}

const levelConfig = {
  strong: { icon: CheckCircle2, label: "Strong", className: "border-primary/40 bg-primary/5" },
  moderate: { icon: AlertCircle, label: "Moderate", className: "border-yellow-500/40 bg-yellow-500/5" },
  missing: { icon: AlertCircle, label: "Missing", className: "border-destructive/40 bg-destructive/5" },
};

const SkillCard = ({ name, level, category }: SkillCardProps) => {
  const config = levelConfig[level];
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-xl border p-4 ${config.className} transition-all hover:scale-[1.02]`}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="font-semibold text-foreground">{name}</p>
          <p className="text-xs text-muted-foreground mt-1">{category}</p>
        </div>
        <Icon
          className={`h-5 w-5 ${
            level === "strong"
              ? "text-primary"
              : level === "moderate"
              ? "text-yellow-500"
              : "text-destructive"
          }`}
        />
      </div>
      <span
        className={`inline-block mt-3 text-xs px-2 py-0.5 rounded-full font-medium ${
          level === "strong"
            ? "bg-primary/20 text-primary"
            : level === "moderate"
            ? "bg-yellow-500/20 text-yellow-500"
            : "bg-destructive/20 text-destructive"
        }`}
      >
        {config.label}
      </span>
    </motion.div>
  );
};

export default SkillCard;

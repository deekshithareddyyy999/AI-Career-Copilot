import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BrainCircuit, Sparkles, ThumbsUp, AlertTriangle, ListChecks, Loader2, RefreshCw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface AICareerAdviceProps {
  detectedSkills: { name: string; level: string; category: string }[];
  missingSkills: { name: string; level: string; category: string }[];
  targetRole: string;
  readinessScore: number;
}

interface Advice {
  strengths: string;
  weaknesses: string;
  nextSteps: string[];
}

const AICareerAdvice = ({ detectedSkills, missingSkills, targetRole, readinessScore }: AICareerAdviceProps) => {
  const [advice, setAdvice] = useState<Advice | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const fetchAdvice = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("career-advice", {
        body: { detectedSkills, missingSkills, targetRole, readinessScore },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setAdvice(data);
    } catch (err: any) {
      console.error("AI advice error:", err);
      toast.error(err.message || "Failed to get AI advice. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <motion.button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 h-14 w-14 rounded-full bg-gradient-to-br from-primary to-accent shadow-glow flex items-center justify-center hover:scale-110 transition-transform cursor-pointer"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        title="AI Career Advice"
      >
        <BrainCircuit className="h-6 w-6 text-primary-foreground" />
      </motion.button>

      {/* Overlay + Panel */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-background/60 backdrop-blur-sm"
              onClick={() => setIsOpen(false)}
            />
            <motion.div
              initial={{ x: "100%", opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: "100%", opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="fixed top-0 right-0 z-50 h-full w-full max-w-md bg-card border-l border-border shadow-2xl overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-5 border-b border-border/30 sticky top-0 bg-card z-10">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-xl bg-primary/15 flex items-center justify-center">
                    <BrainCircuit className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground flex items-center gap-2">
                      AI Career Advice
                      <Sparkles className="h-4 w-4 text-primary" />
                    </h3>
                    <p className="text-xs text-muted-foreground">For {targetRole}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {advice && (
                    <Button variant="ghost" size="icon" onClick={fetchAdvice} disabled={isLoading}>
                      <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <AnimatePresence mode="wait">
                  {!advice && !isLoading && (
                    <motion.div
                      key="cta"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="text-center py-12"
                    >
                      <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                        <Sparkles className="h-8 w-8 text-primary" />
                      </div>
                      <p className="text-sm text-muted-foreground mb-6">
                        Get AI-powered career guidance based on your resume analysis.
                      </p>
                      <Button
                        onClick={fetchAdvice}
                        className="bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-opacity"
                      >
                        <Sparkles className="mr-2 h-4 w-4" />
                        Generate Career Advice
                      </Button>
                    </motion.div>
                  )}

                  {isLoading && (
                    <motion.div
                      key="loading"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="text-center py-16"
                    >
                      <Loader2 className="h-8 w-8 text-primary animate-spin mx-auto mb-3" />
                      <p className="text-sm text-muted-foreground">Analyzing your profile with AI...</p>
                    </motion.div>
                  )}

                  {advice && !isLoading && (
                    <motion.div
                      key="advice"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="space-y-5"
                    >
                      {/* Strengths */}
                      <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/20 p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <ThumbsUp className="h-4 w-4 text-emerald-400" />
                          <h4 className="font-semibold text-sm text-emerald-400">Strengths</h4>
                        </div>
                        <p className="text-sm text-foreground/90 leading-relaxed">{advice.strengths}</p>
                      </div>

                      {/* Weaknesses */}
                      <div className="rounded-xl bg-amber-500/10 border border-amber-500/20 p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <AlertTriangle className="h-4 w-4 text-amber-400" />
                          <h4 className="font-semibold text-sm text-amber-400">Areas to Improve</h4>
                        </div>
                        <p className="text-sm text-foreground/90 leading-relaxed">{advice.weaknesses}</p>
                      </div>

                      {/* Next Steps */}
                      <div className="rounded-xl bg-primary/5 border border-primary/20 p-4">
                        <div className="flex items-center gap-2 mb-3">
                          <ListChecks className="h-4 w-4 text-primary" />
                          <h4 className="font-semibold text-sm text-primary">Recommended Next Steps</h4>
                        </div>
                        <ul className="space-y-2">
                          {advice.nextSteps.map((step, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-foreground/90">
                              <span className="flex-shrink-0 h-5 w-5 rounded-full bg-primary/15 text-primary text-xs font-bold flex items-center justify-center mt-0.5">
                                {i + 1}
                              </span>
                              {step}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default AICareerAdvice;

export interface ExtractedSkill {
  name: string;
  category: string;
  confidence: "high" | "medium";
}

interface SkillPattern {
  name: string;
  category: string;
  keywords: string[];
}

const SKILL_PATTERNS: SkillPattern[] = [
  // Programming Languages
  { name: "Python", category: "Programming", keywords: ["python", "py", "django", "flask", "fastapi"] },
  { name: "JavaScript", category: "Programming", keywords: ["javascript", "js", "es6", "es2015"] },
  { name: "TypeScript", category: "Programming", keywords: ["typescript", "ts"] },
  { name: "Java", category: "Programming", keywords: ["java", "spring", "spring boot", "jvm"] },
  { name: "C++", category: "Programming", keywords: ["c++", "cpp"] },
  { name: "R", category: "Programming", keywords: [" r ", "r programming", "rstudio", "r-studio"] },
  { name: "Go", category: "Programming", keywords: ["golang", "go lang"] },
  { name: "Rust", category: "Programming", keywords: ["rust", "rustlang"] },
  { name: "Scala", category: "Programming", keywords: ["scala", "spark scala"] },
  { name: "SQL", category: "Data", keywords: ["sql", "mysql", "postgresql", "postgres", "sqlite", "tsql", "plsql"] },

  // AI/ML
  { name: "TensorFlow", category: "AI/ML", keywords: ["tensorflow", "tf", "keras"] },
  { name: "PyTorch", category: "AI/ML", keywords: ["pytorch", "torch"] },
  { name: "Scikit-learn", category: "AI/ML", keywords: ["scikit-learn", "sklearn", "scikit learn"] },
  { name: "Deep Learning", category: "AI/ML", keywords: ["deep learning", "neural network", "cnn", "rnn", "lstm", "transformer"] },
  { name: "NLP", category: "AI/ML", keywords: ["nlp", "natural language processing", "text mining", "sentiment analysis", "hugging face", "huggingface", "bert", "gpt"] },
  { name: "Computer Vision", category: "AI/ML", keywords: ["computer vision", "opencv", "image recognition", "object detection", "yolo"] },
  { name: "MLOps", category: "AI/ML", keywords: ["mlops", "mlflow", "kubeflow", "model deployment", "model serving"] },
  { name: "LLMs & Prompt Engineering", category: "AI/ML", keywords: ["llm", "large language model", "prompt engineering", "langchain", "llamaindex", "rag", "retrieval augmented"] },
  { name: "Reinforcement Learning", category: "AI/ML", keywords: ["reinforcement learning", "rl", "q-learning"] },

  // Data Tools
  { name: "Pandas", category: "Data", keywords: ["pandas", "dataframe"] },
  { name: "NumPy", category: "Data", keywords: ["numpy", "np"] },
  { name: "Apache Spark", category: "Data", keywords: ["spark", "pyspark", "apache spark"] },
  { name: "Data Visualization", category: "Data", keywords: ["matplotlib", "seaborn", "plotly", "d3", "data visualization", "ggplot"] },
  { name: "Tableau", category: "Data", keywords: ["tableau"] },
  { name: "Power BI", category: "Data", keywords: ["power bi", "powerbi"] },
  { name: "Excel", category: "Data", keywords: ["excel", "spreadsheet", "vlookup", "pivot table"] },
  { name: "ETL", category: "Data", keywords: ["etl", "data pipeline", "airflow", "data engineering"] },

  // Databases
  { name: "MongoDB", category: "Databases", keywords: ["mongodb", "mongo", "nosql"] },
  { name: "PostgreSQL", category: "Databases", keywords: ["postgresql", "postgres"] },
  { name: "Redis", category: "Databases", keywords: ["redis"] },
  { name: "Elasticsearch", category: "Databases", keywords: ["elasticsearch", "elastic search", "elk"] },
  { name: "Vector Databases", category: "Databases", keywords: ["pinecone", "weaviate", "chroma", "chromadb", "vector database", "vector db", "milvus"] },

  // Cloud
  { name: "AWS", category: "Cloud", keywords: ["aws", "amazon web services", "ec2", "s3", "lambda", "sagemaker"] },
  { name: "GCP", category: "Cloud", keywords: ["gcp", "google cloud", "bigquery", "vertex ai", "cloud functions"] },
  { name: "Azure", category: "Cloud", keywords: ["azure", "microsoft azure", "azure ml"] },

  // DevOps/Tools
  { name: "Docker", category: "DevOps", keywords: ["docker", "container", "dockerfile"] },
  { name: "Kubernetes", category: "DevOps", keywords: ["kubernetes", "k8s"] },
  { name: "Git", category: "Tools", keywords: ["git", "github", "gitlab", "version control"] },
  { name: "CI/CD", category: "DevOps", keywords: ["ci/cd", "ci cd", "jenkins", "github actions", "gitlab ci"] },
  { name: "Linux", category: "Tools", keywords: ["linux", "ubuntu", "bash", "shell scripting"] },

  // Frameworks
  { name: "React", category: "Frameworks", keywords: ["react", "reactjs", "react.js", "next.js", "nextjs"] },
  { name: "Node.js", category: "Frameworks", keywords: ["node.js", "nodejs", "express", "express.js"] },
  { name: "FastAPI", category: "Frameworks", keywords: ["fastapi", "fast api"] },
  { name: "Django", category: "Frameworks", keywords: ["django"] },
  { name: "Flask", category: "Frameworks", keywords: ["flask"] },

  // Statistics/Math
  { name: "Statistics", category: "Math", keywords: ["statistics", "statistical analysis", "hypothesis testing", "regression", "bayesian"] },
  { name: "A/B Testing", category: "Analytics", keywords: ["a/b testing", "ab testing", "experimentation", "hypothesis"] },
  { name: "Mathematics", category: "Math", keywords: ["linear algebra", "calculus", "probability", "optimization"] },

  // Soft Skills
  { name: "Communication", category: "Soft Skills", keywords: ["communication", "presentation", "stakeholder", "cross-functional"] },
  { name: "Project Management", category: "Soft Skills", keywords: ["project management", "agile", "scrum", "jira", "kanban"] },
  { name: "Leadership", category: "Soft Skills", keywords: ["leadership", "team lead", "mentoring", "managing"] },
];

export function extractSkills(resumeText: string): ExtractedSkill[] {
  const text = resumeText.toLowerCase();
  const found: ExtractedSkill[] = [];
  const seenSkills = new Set<string>();

  for (const pattern of SKILL_PATTERNS) {
    if (seenSkills.has(pattern.name)) continue;

    let matchCount = 0;
    for (const keyword of pattern.keywords) {
      // Use word boundary matching for short keywords to avoid false positives
      if (keyword.length <= 3) {
        // For very short keywords, require word boundaries
        const regex = new RegExp(`\\b${keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
        if (regex.test(text)) {
          matchCount++;
        }
      } else {
        if (text.includes(keyword)) {
          matchCount++;
        }
      }
    }

    if (matchCount > 0) {
      seenSkills.add(pattern.name);
      found.push({
        name: pattern.name,
        category: pattern.category,
        confidence: matchCount >= 2 ? "high" : "medium",
      });
    }
  }

  return found;
}

export function getAllSkillPatterns(): SkillPattern[] {
  return SKILL_PATTERNS;
}

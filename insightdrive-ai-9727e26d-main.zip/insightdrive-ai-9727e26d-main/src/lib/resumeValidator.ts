/**
 * Validates whether extracted text looks like a resume vs a random document.
 * Returns { valid, reason } where reason explains rejection.
 */

const RESUME_INDICATORS = [
  // Section headers commonly found in resumes
  "experience", "work experience", "professional experience", "employment",
  "education", "academic", "university", "college", "degree", "bachelor", "master",
  "skills", "technical skills", "core competencies", "proficiencies",
  "projects", "personal projects", "academic projects",
  "summary", "objective", "profile", "about me",
  "certifications", "certificates", "awards",
  "contact", "email", "phone", "linkedin",
  "internship", "intern",
  "resume", "curriculum vitae", "cv",
];

const CONTACT_PATTERNS = [
  /[\w.-]+@[\w.-]+\.\w{2,}/, // email
  /\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/, // phone (US-style)
  /\+?\d{10,13}/, // international phone
  /linkedin\.com/i,
  /github\.com/i,
];

export interface ValidationResult {
  valid: boolean;
  reason: string;
  confidence: number; // 0-100 how confident we are this is a resume
}

export function validateResume(text: string): ValidationResult {
  if (!text || text.trim().length < 50) {
    return { valid: false, reason: "The uploaded file contains too little text to be a resume.", confidence: 0 };
  }

  const lower = text.toLowerCase();

  // Count resume indicator matches
  let indicatorCount = 0;
  const matchedIndicators: string[] = [];
  for (const indicator of RESUME_INDICATORS) {
    if (lower.includes(indicator)) {
      indicatorCount++;
      matchedIndicators.push(indicator);
    }
  }

  // Count contact pattern matches
  let contactCount = 0;
  for (const pattern of CONTACT_PATTERNS) {
    if (pattern.test(text)) {
      contactCount++;
    }
  }

  // Calculate confidence
  // A typical resume has at least 3-4 section indicators and 1-2 contact patterns
  const indicatorScore = Math.min(indicatorCount / 4, 1) * 60; // max 60 from indicators
  const contactScore = Math.min(contactCount / 1, 1) * 20; // max 20 from contacts
  const lengthScore = Math.min(text.length / 500, 1) * 20; // max 20 from length

  const confidence = Math.round(indicatorScore + contactScore + lengthScore);

  if (confidence < 25) {
    return {
      valid: false,
      reason: "This doesn't appear to be a resume. Please upload a file containing your work experience, skills, and education.",
      confidence,
    };
  }

  if (indicatorCount < 2 && contactCount === 0) {
    return {
      valid: false,
      reason: "Could not detect resume sections (experience, education, skills). Please ensure your resume has clear section headings.",
      confidence,
    };
  }

  return { valid: true, reason: "Resume validated successfully.", confidence };
}

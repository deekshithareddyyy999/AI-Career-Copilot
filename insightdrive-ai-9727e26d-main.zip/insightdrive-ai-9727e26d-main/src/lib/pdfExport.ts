import jsPDF from "jspdf";
import type { AnalysisResult } from "./skillAnalysis";
import type { GeneratedRoadmap } from "./roadmapGenerator";

export function downloadRoadmapPDF(analysis: AnalysisResult, roadmap: GeneratedRoadmap) {
  const doc = new jsPDF();
  const margin = 20;
  let y = margin;
  const pageWidth = doc.internal.pageSize.getWidth();
  const contentWidth = pageWidth - margin * 2;

  const addPage = () => {
    doc.addPage();
    y = margin;
  };

  const checkPage = (needed: number) => {
    if (y + needed > doc.internal.pageSize.getHeight() - margin) {
      addPage();
    }
  };

  // Title
  doc.setFontSize(22);
  doc.setFont("helvetica", "bold");
  doc.text("AI Career Copilot", margin, y);
  y += 10;
  doc.setFontSize(14);
  doc.setFont("helvetica", "normal");
  doc.text(`Career Roadmap Report`, margin, y);
  y += 8;
  doc.setFontSize(11);
  doc.text(`Target Role: ${analysis.targetRole}`, margin, y);
  y += 6;
  doc.text(`Readiness Score: ${analysis.readinessScore}/100`, margin, y);
  y += 6;
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, margin, y);
  y += 12;

  // Divider
  doc.setDrawColor(0, 180, 160);
  doc.setLineWidth(0.5);
  doc.line(margin, y, pageWidth - margin, y);
  y += 10;

  // Detected Skills
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text("Detected Skills", margin, y);
  y += 8;
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  for (const skill of analysis.detectedSkills) {
    checkPage(6);
    doc.text(`✓ ${skill.name} (${skill.level}) — ${skill.category}`, margin + 4, y);
    y += 6;
  }
  y += 6;

  // Missing Skills
  checkPage(14);
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text("Skills to Learn", margin, y);
  y += 8;
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  for (const skill of analysis.missingSkills) {
    checkPage(6);
    doc.text(`✗ ${skill.name} — ${skill.category}`, margin + 4, y);
    y += 6;
  }
  y += 6;

  // Roadmap
  checkPage(14);
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text(`${roadmap.duration} Learning Roadmap`, margin, y);
  y += 10;

  for (const week of roadmap.weeks) {
    checkPage(20);
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text(`Week ${week.week}: ${week.title}`, margin, y);
    y += 7;

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    for (const task of week.tasks) {
      checkPage(12);
      const prefix = task.type === "course" ? "📚" : task.type === "project" ? "🛠" : "🎯";
      doc.text(`${prefix} ${task.title} — ${task.resource}`, margin + 4, y);
      y += 5;
      if (task.resourceUrl) {
        doc.setTextColor(0, 102, 204);
        doc.textWithLink(task.resourceUrl, margin + 8, y, { url: task.resourceUrl });
        doc.setTextColor(0, 0, 0);
        y += 6;
      } else {
        y += 1;
      }
    }

    doc.setFont("helvetica", "italic");
    checkPage(6);
    doc.text(`Milestone: ${week.milestone}`, margin + 4, y);
    y += 10;
    doc.setFont("helvetica", "normal");
  }

  // Suggested Projects
  checkPage(20);
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text("Suggested Projects", margin, y);
  y += 8;
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  for (const proj of roadmap.suggestedProjects) {
    checkPage(6);
    doc.text(`• ${proj}`, margin + 4, y);
    y += 6;
  }

  // Recommended Technologies
  y += 6;
  checkPage(14);
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text("Recommended Technologies", margin, y);
  y += 8;
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(roadmap.recommendedTech.join(", "), margin + 4, y, { maxWidth: contentWidth - 4 });

  doc.save(`career-roadmap-${analysis.targetRole.toLowerCase().replace(/\s+/g, "-")}.pdf`);
}

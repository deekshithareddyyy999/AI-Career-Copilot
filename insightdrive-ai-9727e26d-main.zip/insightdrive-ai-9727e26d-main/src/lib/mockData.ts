export interface SkillItem {
  name: string;
  level: "strong" | "moderate" | "missing";
  category: string;
}

export interface RoleComparison {
  role: string;
  score: number;
}

export interface RoadmapStep {
  title: string;
  resource: string;
  type: string;
}

export interface RoadmapPhase {
  phase: string;
  steps: RoadmapStep[];
}

export interface AnalysisData {
  name: string;
  targetRole: string;
  readinessScore: number;
  detectedSkills: SkillItem[];
  missingSkills: SkillItem[];
  roleComparison: RoleComparison[];
  roadmap: RoadmapPhase[];
}

const roleAnalysisMap: Record<string, AnalysisData> = {
  "data scientist": {
    name: "Alex Johnson",
    targetRole: "Data Scientist",
    readinessScore: 68,
    detectedSkills: [
      { name: "Python", level: "strong", category: "Programming" },
      { name: "SQL", level: "strong", category: "Data" },
      { name: "Pandas", level: "strong", category: "Data" },
      { name: "NumPy", level: "moderate", category: "Data" },
      { name: "Scikit-learn", level: "moderate", category: "ML" },
      { name: "Data Visualization", level: "strong", category: "Data" },
      { name: "Statistics", level: "moderate", category: "Math" },
      { name: "Git", level: "strong", category: "Tools" },
    ],
    missingSkills: [
      { name: "Deep Learning", level: "missing", category: "ML" },
      { name: "TensorFlow / PyTorch", level: "missing", category: "ML" },
      { name: "NLP", level: "missing", category: "ML" },
      { name: "MLOps", level: "missing", category: "Engineering" },
      { name: "Cloud (AWS/GCP)", level: "missing", category: "Infrastructure" },
      { name: "A/B Testing", level: "missing", category: "Analytics" },
    ],
    roleComparison: [
      { role: "Data Analyst", score: 85 },
      { role: "Data Scientist", score: 68 },
      { role: "ML Engineer", score: 45 },
      { role: "AI Engineer", score: 32 },
    ],
    roadmap: [
      {
        phase: "Phase 1 — Foundations (Weeks 1–4)",
        steps: [
          { title: "Complete Deep Learning Specialization", resource: "Coursera – Andrew Ng", type: "course" },
          { title: "Build 3 neural network projects", resource: "Kaggle", type: "project" },
          { title: "Learn TensorFlow basics", resource: "TensorFlow docs", type: "course" },
        ],
      },
      {
        phase: "Phase 2 — Specialization (Weeks 5–8)",
        steps: [
          { title: "NLP with Transformers", resource: "Hugging Face course", type: "course" },
          { title: "Deploy ML model on AWS", resource: "AWS SageMaker tutorial", type: "project" },
          { title: "Learn MLOps fundamentals", resource: "Made With ML", type: "course" },
        ],
      },
      {
        phase: "Phase 3 — Portfolio & Prep (Weeks 9–12)",
        steps: [
          { title: "Build end-to-end ML pipeline", resource: "Personal project", type: "project" },
          { title: "Contribute to open source ML project", resource: "GitHub", type: "project" },
          { title: "Practice ML system design interviews", resource: "Educative.io", type: "prep" },
        ],
      },
    ],
  },

  "data analyst": {
    name: "Alex Johnson",
    targetRole: "Data Analyst",
    readinessScore: 82,
    detectedSkills: [
      { name: "SQL", level: "strong", category: "Data" },
      { name: "Excel", level: "strong", category: "Tools" },
      { name: "Python", level: "moderate", category: "Programming" },
      { name: "Data Visualization", level: "strong", category: "Data" },
      { name: "Pandas", level: "moderate", category: "Data" },
      { name: "Statistics", level: "moderate", category: "Math" },
    ],
    missingSkills: [
      { name: "Tableau / Power BI", level: "missing", category: "Visualization" },
      { name: "A/B Testing", level: "missing", category: "Analytics" },
      { name: "Data Warehousing", level: "missing", category: "Infrastructure" },
      { name: "Stakeholder Communication", level: "missing", category: "Soft Skills" },
    ],
    roleComparison: [
      { role: "Data Analyst", score: 82 },
      { role: "Business Analyst", score: 74 },
      { role: "Data Scientist", score: 55 },
      { role: "Analytics Engineer", score: 48 },
    ],
    roadmap: [
      {
        phase: "Phase 1 — Core Tools (Weeks 1–3)",
        steps: [
          { title: "Master Tableau dashboards", resource: "Tableau Public tutorials", type: "course" },
          { title: "Advanced SQL (window functions, CTEs)", resource: "Mode Analytics SQL tutorial", type: "course" },
          { title: "Build 2 portfolio dashboards", resource: "Kaggle datasets", type: "project" },
        ],
      },
      {
        phase: "Phase 2 — Analytics Skills (Weeks 4–6)",
        steps: [
          { title: "Learn A/B testing & experimentation", resource: "Udacity free course", type: "course" },
          { title: "Data storytelling with stakeholders", resource: "Storytelling with Data book", type: "course" },
          { title: "Automate a reporting pipeline", resource: "Python + Google Sheets API", type: "project" },
        ],
      },
      {
        phase: "Phase 3 — Job Prep (Weeks 7–8)",
        steps: [
          { title: "Practice SQL interview questions", resource: "StrataScratch", type: "prep" },
          { title: "Create a case study portfolio", resource: "Personal project", type: "project" },
          { title: "Mock interviews with peers", resource: "Pramp", type: "prep" },
        ],
      },
    ],
  },

  "ml engineer": {
    name: "Alex Johnson",
    targetRole: "ML Engineer",
    readinessScore: 52,
    detectedSkills: [
      { name: "Python", level: "strong", category: "Programming" },
      { name: "Git", level: "strong", category: "Tools" },
      { name: "SQL", level: "moderate", category: "Data" },
      { name: "Scikit-learn", level: "moderate", category: "ML" },
      { name: "Docker", level: "moderate", category: "DevOps" },
    ],
    missingSkills: [
      { name: "Deep Learning (PyTorch)", level: "missing", category: "ML" },
      { name: "MLOps & CI/CD", level: "missing", category: "Engineering" },
      { name: "Kubernetes", level: "missing", category: "Infrastructure" },
      { name: "Model Serving (TFServing, Triton)", level: "missing", category: "Deployment" },
      { name: "Feature Engineering at Scale", level: "missing", category: "Data" },
      { name: "Cloud ML Services (SageMaker, Vertex AI)", level: "missing", category: "Cloud" },
      { name: "System Design for ML", level: "missing", category: "Architecture" },
    ],
    roleComparison: [
      { role: "Data Analyst", score: 70 },
      { role: "Data Scientist", score: 58 },
      { role: "ML Engineer", score: 52 },
      { role: "AI Engineer", score: 40 },
    ],
    roadmap: [
      {
        phase: "Phase 1 — Deep Learning & Frameworks (Weeks 1–4)",
        steps: [
          { title: "Complete PyTorch fundamentals", resource: "PyTorch official tutorials", type: "course" },
          { title: "Build & train CNNs and RNNs", resource: "Fast.ai course", type: "project" },
          { title: "Experiment tracking with MLflow", resource: "MLflow docs", type: "course" },
        ],
      },
      {
        phase: "Phase 2 — MLOps & Deployment (Weeks 5–8)",
        steps: [
          { title: "Learn Kubernetes basics", resource: "Kubernetes.io tutorials", type: "course" },
          { title: "Deploy model with FastAPI + Docker", resource: "Personal project", type: "project" },
          { title: "Set up ML CI/CD pipeline", resource: "GitHub Actions + DVC", type: "project" },
        ],
      },
      {
        phase: "Phase 3 — Scale & Interview (Weeks 9–12)",
        steps: [
          { title: "Learn distributed training", resource: "Hugging Face Accelerate", type: "course" },
          { title: "Build end-to-end ML system", resource: "Personal project", type: "project" },
          { title: "Practice ML system design", resource: "Designing ML Systems book", type: "prep" },
        ],
      },
    ],
  },

  "frontend developer": {
    name: "Alex Johnson",
    targetRole: "Frontend Developer",
    readinessScore: 45,
    detectedSkills: [
      { name: "HTML/CSS", level: "moderate", category: "Web" },
      { name: "JavaScript", level: "moderate", category: "Programming" },
      { name: "Git", level: "strong", category: "Tools" },
      { name: "Python", level: "strong", category: "Programming" },
    ],
    missingSkills: [
      { name: "React / Vue / Angular", level: "missing", category: "Frameworks" },
      { name: "TypeScript", level: "missing", category: "Programming" },
      { name: "Responsive Design", level: "missing", category: "UI/UX" },
      { name: "State Management (Redux, Zustand)", level: "missing", category: "Architecture" },
      { name: "Testing (Jest, Cypress)", level: "missing", category: "QA" },
      { name: "Web Performance", level: "missing", category: "Optimization" },
    ],
    roleComparison: [
      { role: "Frontend Developer", score: 45 },
      { role: "Full Stack Developer", score: 38 },
      { role: "UI/UX Engineer", score: 30 },
      { role: "Data Analyst", score: 72 },
    ],
    roadmap: [
      {
        phase: "Phase 1 — Core Frontend (Weeks 1–4)",
        steps: [
          { title: "Master React fundamentals", resource: "React.dev official docs", type: "course" },
          { title: "Learn TypeScript essentials", resource: "TypeScript Handbook", type: "course" },
          { title: "Build a portfolio website", resource: "Personal project", type: "project" },
        ],
      },
      {
        phase: "Phase 2 — Advanced Patterns (Weeks 5–8)",
        steps: [
          { title: "State management with Zustand/Redux", resource: "Zustand docs", type: "course" },
          { title: "Learn Tailwind CSS", resource: "Tailwind docs", type: "course" },
          { title: "Build a full CRUD application", resource: "Personal project", type: "project" },
        ],
      },
      {
        phase: "Phase 3 — Polish & Prep (Weeks 9–12)",
        steps: [
          { title: "Learn testing with Jest & React Testing Library", resource: "Testing Library docs", type: "course" },
          { title: "Optimize web performance (Lighthouse)", resource: "web.dev", type: "project" },
          { title: "Practice frontend interview challenges", resource: "GreatFrontEnd", type: "prep" },
        ],
      },
    ],
  },

  "product manager": {
    name: "Alex Johnson",
    targetRole: "Product Manager",
    readinessScore: 40,
    detectedSkills: [
      { name: "Data Analysis", level: "moderate", category: "Analytics" },
      { name: "SQL", level: "moderate", category: "Data" },
      { name: "Communication", level: "strong", category: "Soft Skills" },
      { name: "Project Management", level: "moderate", category: "Management" },
    ],
    missingSkills: [
      { name: "Product Strategy", level: "missing", category: "Product" },
      { name: "User Research & Interviews", level: "missing", category: "UX" },
      { name: "Roadmap Planning", level: "missing", category: "Product" },
      { name: "A/B Testing & Metrics", level: "missing", category: "Analytics" },
      { name: "Wireframing (Figma)", level: "missing", category: "Design" },
      { name: "Agile / Scrum", level: "missing", category: "Process" },
    ],
    roleComparison: [
      { role: "Product Manager", score: 40 },
      { role: "Business Analyst", score: 55 },
      { role: "Project Manager", score: 50 },
      { role: "Data Analyst", score: 65 },
    ],
    roadmap: [
      {
        phase: "Phase 1 — PM Fundamentals (Weeks 1–4)",
        steps: [
          { title: "Learn product thinking & frameworks", resource: "Inspired by Marty Cagan", type: "course" },
          { title: "Practice PRD writing", resource: "Lenny's Newsletter templates", type: "project" },
          { title: "Run 5 user interviews", resource: "Friends & colleagues", type: "project" },
        ],
      },
      {
        phase: "Phase 2 — Execution Skills (Weeks 5–8)",
        steps: [
          { title: "Learn Agile & Scrum methodology", resource: "Scrum.org", type: "course" },
          { title: "Master metrics & KPIs", resource: "Reforge growth series", type: "course" },
          { title: "Build a product case study", resource: "Personal project", type: "project" },
        ],
      },
      {
        phase: "Phase 3 — Interview Prep (Weeks 9–12)",
        steps: [
          { title: "Practice product sense questions", resource: "Exponent PM course", type: "prep" },
          { title: "Mock PM interviews", resource: "Pramp / Exponent", type: "prep" },
          { title: "Build a public PM portfolio", resource: "Notion / personal site", type: "project" },
        ],
      },
    ],
  },

  "ai engineer": {
    name: "Alex Johnson",
    targetRole: "AI Engineer",
    readinessScore: 35,
    detectedSkills: [
      { name: "Python", level: "strong", category: "Programming" },
      { name: "Git", level: "strong", category: "Tools" },
      { name: "SQL", level: "moderate", category: "Data" },
      { name: "Statistics", level: "moderate", category: "Math" },
    ],
    missingSkills: [
      { name: "LLMs & Prompt Engineering", level: "missing", category: "AI" },
      { name: "RAG & Vector Databases", level: "missing", category: "AI" },
      { name: "LangChain / LlamaIndex", level: "missing", category: "Frameworks" },
      { name: "Fine-tuning Models", level: "missing", category: "ML" },
      { name: "API Design & Integration", level: "missing", category: "Engineering" },
      { name: "Cloud Deployment", level: "missing", category: "Infrastructure" },
      { name: "Evaluation & Guardrails", level: "missing", category: "AI Safety" },
    ],
    roleComparison: [
      { role: "Data Analyst", score: 65 },
      { role: "Data Scientist", score: 50 },
      { role: "ML Engineer", score: 42 },
      { role: "AI Engineer", score: 35 },
    ],
    roadmap: [
      {
        phase: "Phase 1 — AI Foundations (Weeks 1–4)",
        steps: [
          { title: "Learn LLM fundamentals & prompt engineering", resource: "DeepLearning.AI short courses", type: "course" },
          { title: "Build a RAG chatbot", resource: "LangChain docs", type: "project" },
          { title: "Understand embeddings & vector DBs", resource: "Pinecone learning center", type: "course" },
        ],
      },
      {
        phase: "Phase 2 — Advanced AI Engineering (Weeks 5–8)",
        steps: [
          { title: "Fine-tune an open source LLM", resource: "Hugging Face + LoRA", type: "project" },
          { title: "Build AI agents with tool use", resource: "LangGraph tutorials", type: "project" },
          { title: "Learn evaluation frameworks", resource: "RAGAS / LangSmith", type: "course" },
        ],
      },
      {
        phase: "Phase 3 — Production & Portfolio (Weeks 9–12)",
        steps: [
          { title: "Deploy AI app to production", resource: "Vercel + FastAPI", type: "project" },
          { title: "Implement guardrails & safety", resource: "NeMo Guardrails", type: "project" },
          { title: "Prepare AI engineer interview portfolio", resource: "Personal projects showcase", type: "prep" },
        ],
      },
    ],
  },
};

// Fuzzy match: find the best matching role key
function findBestRoleMatch(input: string): string {
  const normalized = input.toLowerCase().trim();
  
  // Exact match
  if (roleAnalysisMap[normalized]) return normalized;
  
  // Partial match
  const keys = Object.keys(roleAnalysisMap);
  for (const key of keys) {
    if (normalized.includes(key) || key.includes(normalized)) return key;
  }
  
  // Keyword matching
  const keywordMap: Record<string, string[]> = {
    "data scientist": ["data science", "ds", "scientist"],
    "data analyst": ["analyst", "analytics", "data analysis", "bi analyst"],
    "ml engineer": ["machine learning", "ml", "mlops"],
    "ai engineer": ["ai", "artificial intelligence", "llm", "genai", "gen ai"],
    "frontend developer": ["frontend", "front end", "front-end", "react", "ui developer", "web developer"],
    "product manager": ["product", "pm", "product owner"],
  };
  
  for (const [role, keywords] of Object.entries(keywordMap)) {
    if (keywords.some((kw) => normalized.includes(kw))) return role;
  }
  
  // Default fallback
  return "data scientist";
}

export function getAnalysisForRole(targetRole: string): AnalysisData {
  const matchedKey = findBestRoleMatch(targetRole);
  const data = { ...roleAnalysisMap[matchedKey] };
  // Override the targetRole display name with the user's input
  data.targetRole = targetRole;
  return data;
}

// Keep backward compat
export const mockAnalysis = roleAnalysisMap["data scientist"];

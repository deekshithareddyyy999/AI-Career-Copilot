import type { AnalysisResult } from "./skillAnalysis";

export interface RoadmapWeek {
  week: number;
  title: string;
  tasks: RoadmapTask[];
  milestone: string;
}

export interface RoadmapTask {
  title: string;
  resource: string;
  resourceUrl: string;
  type: "course" | "project" | "practice" | "prep";
  completed: boolean;
}

export interface GeneratedRoadmap {
  duration: "4-week" | "8-week";
  weeks: RoadmapWeek[];
  recommendedTech: string[];
  suggestedProjects: string[];
}

// Role-specific skill ordering — controls which skills appear and in what priority
const ROLE_SKILL_PRIORITY: Record<string, string[]> = {
  "Software Engineer": [
    "JavaScript", "TypeScript", "Python", "SQL", "Git", "React", "Node.js",
    "PostgreSQL", "MongoDB", "Docker", "CI/CD", "AWS", "Kubernetes", "Redis",
    "Linux", "Java", "Go", "FastAPI", "Communication",
  ],
  "Frontend Developer": [
    "JavaScript", "TypeScript", "React", "Git", "Node.js", "Docker", "CI/CD",
    "Linux", "Communication",
  ],
  "Data Analyst": [
    "SQL", "Excel", "Data Visualization", "Statistics", "Python", "Tableau",
    "Power BI", "A/B Testing", "Pandas", "R", "ETL", "Communication", "Project Management",
  ],
  "Data Scientist": [
    "Python", "SQL", "Statistics", "Scikit-learn", "Pandas", "NumPy",
    "Deep Learning", "TensorFlow", "PyTorch", "NLP", "Data Visualization",
    "MLOps", "AWS", "GCP", "A/B Testing", "R", "Mathematics",
  ],
  "AI Engineer": [
    "Python", "Deep Learning", "LLMs & Prompt Engineering", "TensorFlow", "PyTorch",
    "NLP", "Computer Vision", "MLOps", "Docker", "Kubernetes", "AWS", "GCP",
    "FastAPI", "Vector Databases", "Git", "CI/CD", "Reinforcement Learning",
  ],
  "ML Engineer": [
    "Python", "Scikit-learn", "Deep Learning", "Docker", "SQL",
    "PyTorch", "TensorFlow", "MLOps", "Kubernetes", "AWS", "GCP",
    "Apache Spark", "CI/CD", "Git", "FastAPI", "Linux", "Mathematics",
  ],
  "Product Manager": [
    "Communication", "Project Management", "A/B Testing", "SQL",
    "Data Visualization", "Statistics", "Excel", "Python", "Leadership", "Tableau",
  ],
};

interface ResourceInfo {
  course: string;
  courseUrl: string;
  project: string;
  projectUrl: string;
}

const RESOURCE_MAP: Record<string, ResourceInfo> = {
  Python: { course: "Python.org Official Tutorial", courseUrl: "https://docs.python.org/3/tutorial/", project: "Build a CLI data tool", projectUrl: "https://realpython.com/python-command-line-arguments/" },
  JavaScript: { course: "MDN JavaScript Guide", courseUrl: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide", project: "Build an interactive web app", projectUrl: "https://javascript.info/" },
  TypeScript: { course: "TypeScript Handbook", courseUrl: "https://www.typescriptlang.org/docs/handbook/", project: "Convert a JS project to TS", projectUrl: "https://www.typescriptlang.org/docs/handbook/migrating-from-javascript.html" },
  Java: { course: "Oracle Java Tutorials", courseUrl: "https://docs.oracle.com/javase/tutorial/", project: "Build a REST API with Spring Boot", projectUrl: "https://spring.io/guides/gs/rest-service/" },
  Go: { course: "Go Tour", courseUrl: "https://go.dev/tour/welcome/1", project: "Build a concurrent web server", projectUrl: "https://gobyexample.com/" },
  SQL: { course: "SQLBolt Interactive Tutorial", courseUrl: "https://sqlbolt.com/", project: "Analyze a public dataset", projectUrl: "https://mode.com/sql-tutorial/" },
  Git: { course: "Git Official Book", courseUrl: "https://git-scm.com/book/en/v2", project: "Contribute to an open source project", projectUrl: "https://opensource.guide/how-to-contribute/" },
  React: { course: "React.dev Official Docs", courseUrl: "https://react.dev/learn", project: "Build a full CRUD app", projectUrl: "https://react.dev/learn/thinking-in-react" },
  "Node.js": { course: "Node.js Official Docs", courseUrl: "https://nodejs.org/en/learn", project: "Build a REST API with Express", projectUrl: "https://expressjs.com/en/starter/hello-world.html" },
  Docker: { course: "Docker Getting Started", courseUrl: "https://docs.docker.com/get-started/", project: "Containerize a full-stack app", projectUrl: "https://docs.docker.com/compose/gettingstarted/" },
  Kubernetes: { course: "Kubernetes.io Tutorials", courseUrl: "https://kubernetes.io/docs/tutorials/", project: "Deploy to a K8s cluster", projectUrl: "https://kubernetes.io/docs/tutorials/stateless-application/expose-external-ip-address/" },
  AWS: { course: "AWS Free Tier Tutorials", courseUrl: "https://aws.amazon.com/getting-started/", project: "Deploy to EC2/Lambda", projectUrl: "https://aws.amazon.com/getting-started/hands-on/" },
  GCP: { course: "Google Cloud Skills Boost", courseUrl: "https://www.cloudskillsboost.google/", project: "Use BigQuery + Vertex AI", projectUrl: "https://cloud.google.com/bigquery/docs/tutorials" },
  PostgreSQL: { course: "PostgreSQL Tutorial", courseUrl: "https://www.postgresqltutorial.com/", project: "Design a relational database", projectUrl: "https://www.postgresql.org/docs/current/tutorial.html" },
  MongoDB: { course: "MongoDB University", courseUrl: "https://learn.mongodb.com/", project: "Build a NoSQL-backed API", projectUrl: "https://www.mongodb.com/docs/manual/tutorial/" },
  Redis: { course: "Redis University", courseUrl: "https://university.redis.io/", project: "Implement caching layer", projectUrl: "https://redis.io/docs/getting-started/" },
  Linux: { course: "Linux Journey", courseUrl: "https://linuxjourney.com/", project: "Set up a dev server", projectUrl: "https://linuxcommand.org/" },
  "CI/CD": { course: "GitHub Actions Docs", courseUrl: "https://docs.github.com/en/actions", project: "Set up automated CI/CD pipeline", projectUrl: "https://docs.github.com/en/actions/quickstart" },
  "Deep Learning": { course: "Fast.ai Practical Deep Learning", courseUrl: "https://course.fast.ai/", project: "Train an image classifier", projectUrl: "https://www.deeplearning.ai/" },
  TensorFlow: { course: "TensorFlow Official Tutorials", courseUrl: "https://www.tensorflow.org/tutorials", project: "Build a prediction model", projectUrl: "https://www.tensorflow.org/tutorials/keras/classification" },
  PyTorch: { course: "PyTorch Official Tutorials", courseUrl: "https://pytorch.org/tutorials/", project: "Implement a neural network", projectUrl: "https://pytorch.org/tutorials/beginner/basics/intro.html" },
  NLP: { course: "Hugging Face Course", courseUrl: "https://huggingface.co/learn/nlp-course", project: "Build a text classifier", projectUrl: "https://huggingface.co/docs/transformers/tasks/sequence_classification" },
  MLOps: { course: "Made With ML", courseUrl: "https://madewithml.com/", project: "Deploy a model pipeline", projectUrl: "https://mlflow.org/docs/latest/tutorials-and-examples/index.html" },
  "Scikit-learn": { course: "Scikit-learn User Guide", courseUrl: "https://scikit-learn.org/stable/user_guide.html", project: "Build a classification pipeline", projectUrl: "https://scikit-learn.org/stable/tutorial/basic/tutorial.html" },
  Tableau: { course: "Tableau Public Tutorials", courseUrl: "https://public.tableau.com/app/resources/learn", project: "Create interactive dashboards", projectUrl: "https://www.tableau.com/learn/training" },
  "Power BI": { course: "Microsoft Learn – Power BI", courseUrl: "https://learn.microsoft.com/en-us/power-bi/", project: "Build a business report", projectUrl: "https://learn.microsoft.com/en-us/power-bi/fundamentals/desktop-getting-started" },
  "A/B Testing": { course: "Google A/B Testing Course", courseUrl: "https://www.udacity.com/course/ab-testing--ud257", project: "Design and analyze an A/B test", projectUrl: "https://www.optimizely.com/optimization-glossary/ab-testing/" },
  "Data Visualization": { course: "Matplotlib & Seaborn Tutorials", courseUrl: "https://matplotlib.org/stable/tutorials/", project: "Visualize a real dataset", projectUrl: "https://seaborn.pydata.org/tutorial.html" },
  "LLMs & Prompt Engineering": { course: "DeepLearning.AI Short Courses", courseUrl: "https://www.deeplearning.ai/short-courses/", project: "Build a RAG chatbot", projectUrl: "https://python.langchain.com/docs/tutorials/" },
  "Vector Databases": { course: "Pinecone Learning Center", courseUrl: "https://www.pinecone.io/learn/", project: "Build a semantic search engine", projectUrl: "https://docs.pinecone.io/guides/get-started/quickstart" },
  "Computer Vision": { course: "OpenCV Tutorials", courseUrl: "https://docs.opencv.org/4.x/d9/df8/tutorial_root.html", project: "Object detection project", projectUrl: "https://learnopencv.com/" },
  FastAPI: { course: "FastAPI Official Docs", courseUrl: "https://fastapi.tiangolo.com/tutorial/", project: "Build a REST API", projectUrl: "https://fastapi.tiangolo.com/tutorial/first-steps/" },
  Statistics: { course: "Khan Academy Statistics", courseUrl: "https://www.khanacademy.org/math/statistics-probability", project: "Statistical analysis report", projectUrl: "https://www.coursera.org/learn/inferential-statistics-intro" },
  Mathematics: { course: "3Blue1Brown Linear Algebra", courseUrl: "https://www.3blue1brown.com/topics/linear-algebra", project: "Implement gradient descent from scratch", projectUrl: "https://www.khanacademy.org/math/linear-algebra" },
  Excel: { course: "Excel Easy Tutorials", courseUrl: "https://www.excel-easy.com/", project: "Build an automated report", projectUrl: "https://support.microsoft.com/en-us/excel" },
  Pandas: { course: "Pandas Official Getting Started", courseUrl: "https://pandas.pydata.org/docs/getting_started/", project: "Clean and analyze a messy dataset", projectUrl: "https://pandas.pydata.org/docs/user_guide/10min.html" },
  NumPy: { course: "NumPy Quickstart", courseUrl: "https://numpy.org/doc/stable/user/quickstart.html", project: "Implement matrix operations", projectUrl: "https://numpy.org/doc/stable/user/absolute_beginners.html" },
  R: { course: "R for Data Science", courseUrl: "https://r4ds.had.co.nz/", project: "Statistical analysis in R", projectUrl: "https://www.rstudio.com/resources/cheatsheets/" },
  ETL: { course: "Airflow Official Tutorial", courseUrl: "https://airflow.apache.org/docs/apache-airflow/stable/tutorial/", project: "Build a data pipeline", projectUrl: "https://airflow.apache.org/docs/apache-airflow/stable/tutorial/fundamentals.html" },
  "Apache Spark": { course: "Spark Official Quick Start", courseUrl: "https://spark.apache.org/docs/latest/quick-start.html", project: "Process a large dataset", projectUrl: "https://spark.apache.org/docs/latest/sql-getting-started.html" },
  Communication: { course: "Storytelling with Data", courseUrl: "https://www.storytellingwithdata.com/", project: "Present a data case study", projectUrl: "https://www.coursera.org/learn/present-data" },
  "Project Management": { course: "Scrum.org Resources", courseUrl: "https://www.scrum.org/resources", project: "Lead a sprint planning session", projectUrl: "https://www.atlassian.com/agile/scrum" },
  Leadership: { course: "Management Fundamentals", courseUrl: "https://www.coursera.org/learn/management-fundamentals-healthcare-administrators", project: "Mentor a junior colleague", projectUrl: "https://hbr.org/topic/leadership" },
  "Reinforcement Learning": { course: "Spinning Up in Deep RL", courseUrl: "https://spinningup.openai.com/en/latest/", project: "Implement a RL agent", projectUrl: "https://gymnasium.farama.org/" },
  Rust: { course: "The Rust Book", courseUrl: "https://doc.rust-lang.org/book/", project: "Build a CLI tool in Rust", projectUrl: "https://rust-cli.github.io/book/" },
};

export function generateLocalRoadmap(analysis: AnalysisResult, duration: "4-week" | "8-week" = "8-week"): GeneratedRoadmap {
  const missingNames = analysis.missingSkills.map((s) => s.name);
  const totalWeeks = duration === "4-week" ? 4 : 8;

  // Get role-specific priority order, filter to only missing skills
  const rolePriority = ROLE_SKILL_PRIORITY[analysis.targetRole] || [];
  const prioritized = rolePriority.filter((s) => missingNames.includes(s));
  // Add any missing skills not in the priority list at the end
  const remaining = missingNames.filter((s) => !prioritized.includes(s));
  const orderedSkills = [...prioritized, ...remaining];

  const weeks: RoadmapWeek[] = [];
  const skillsPerWeek = Math.max(1, Math.ceil(orderedSkills.length / totalWeeks));

  for (let w = 0; w < totalWeeks; w++) {
    const weekSkills = orderedSkills.slice(w * skillsPerWeek, (w + 1) * skillsPerWeek);
    if (weekSkills.length === 0) continue;

    const tasks: RoadmapTask[] = weekSkills.flatMap((skill) => getTasksForSkill(skill));

    weeks.push({
      week: w + 1,
      title: getWeekTitle(w, totalWeeks),
      tasks,
      milestone: `Master: ${weekSkills.join(", ")}`,
    });
  }

  // Fill remaining weeks with projects and prep
  while (weeks.length < totalWeeks) {
    const w = weeks.length;
    weeks.push({
      week: w + 1,
      title: w === totalWeeks - 1 ? "Interview Preparation" : "Portfolio Building",
      tasks: [
        { title: `Build end-to-end ${analysis.targetRole} project`, resource: "Personal project", resourceUrl: "https://github.com/", type: "project", completed: false },
        { title: "Practice technical interview questions", resource: "LeetCode", resourceUrl: "https://leetcode.com/", type: "prep", completed: false },
        { title: "Create portfolio showcasing projects", resource: "GitHub / Personal site", resourceUrl: "https://pages.github.com/", type: "project", completed: false },
      ],
      milestone: w === totalWeeks - 1 ? "Ready for interviews" : "Portfolio complete",
    });
  }

  const recommendedTech = orderedSkills.slice(0, 8);
  const suggestedProjects = generateProjectSuggestions(analysis.targetRole, orderedSkills);

  return { duration, weeks, recommendedTech, suggestedProjects };
}

function getWeekTitle(weekIndex: number, total: number): string {
  const ratio = weekIndex / total;
  if (ratio < 0.25) return "Foundations & Setup";
  if (ratio < 0.5) return "Core Skill Building";
  if (ratio < 0.75) return "Advanced Topics";
  return "Projects & Practice";
}

function getTasksForSkill(skill: string): RoadmapTask[] {
  const info = RESOURCE_MAP[skill] || {
    course: "Online tutorials",
    courseUrl: `https://www.google.com/search?q=learn+${encodeURIComponent(skill)}`,
    project: `Build a ${skill} project`,
    projectUrl: `https://www.google.com/search?q=${encodeURIComponent(skill)}+project+ideas`,
  };

  return [
    { title: `Learn ${skill}`, resource: info.course, resourceUrl: info.courseUrl, type: "course", completed: false },
    { title: info.project, resource: "Hands-on project", resourceUrl: info.projectUrl, type: "project", completed: false },
  ];
}

function generateProjectSuggestions(role: string, missingSkills: string[]): string[] {
  const roleProjects: Record<string, string[]> = {
    "Data Analyst": [
      "Sales dashboard with Tableau/Power BI",
      "Customer segmentation analysis",
      "A/B test results analysis",
      "Automated reporting pipeline",
    ],
    "Data Scientist": [
      "Predictive model for house prices",
      "Customer churn prediction",
      "Recommendation engine",
      "NLP sentiment analysis tool",
    ],
    "AI Engineer": [
      "RAG-powered chatbot",
      "AI agent with tool use",
      "Fine-tuned LLM for domain tasks",
      "Production AI API with guardrails",
    ],
    "ML Engineer": [
      "End-to-end ML pipeline with CI/CD",
      "Real-time model serving API",
      "Feature store implementation",
      "Distributed training setup",
    ],
    "Software Engineer": [
      "Full-stack web application with auth",
      "REST API with PostgreSQL & Redis caching",
      "CI/CD pipeline with Docker & GitHub Actions",
      "Microservices architecture project",
    ],
    "Frontend Developer": [
      "Full-stack CRUD application",
      "Real-time dashboard with WebSockets",
      "Accessible component library",
      "Performance-optimized SPA",
    ],
    "Product Manager": [
      "Product requirements document",
      "User research report",
      "Metrics dashboard design",
      "Go-to-market strategy",
    ],
  };

  return roleProjects[role] || roleProjects["Software Engineer"];
}

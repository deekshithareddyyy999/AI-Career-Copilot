import * as pdfjsLib from "pdfjs-dist";
import mammoth from "mammoth";

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

export interface ParseResult {
  text: string;
  pageCount: number;
}

export async function parseResume(file: File): Promise<ParseResult> {
  if (file.type === "application/pdf") {
    return parsePDF(file);
  } else if (
    file.type ===
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ) {
    return parseDOCX(file);
  }
  throw new Error("Unsupported file type. Please upload a PDF or DOCX file.");
}

async function parsePDF(file: File): Promise<ParseResult> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  const textParts: string[] = [];

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();

    // Group text items by their Y position to reconstruct lines properly
    const items = content.items as any[];
    if (items.length === 0) continue;

    // Sort by Y (descending = top to bottom) then X (left to right)
    const sorted = [...items].sort((a, b) => {
      const yDiff = b.transform[5] - a.transform[5];
      if (Math.abs(yDiff) > 2) return yDiff; // different line
      return a.transform[4] - b.transform[4]; // same line, sort by X
    });

    const lines: string[] = [];
    let currentLine: string[] = [];
    let lastY = sorted[0]?.transform[5] ?? 0;

    for (const item of sorted) {
      const y = item.transform[5];
      const str = item.str;
      if (!str) continue;

      // If Y position changed significantly, it's a new line
      if (Math.abs(y - lastY) > 2) {
        if (currentLine.length > 0) {
          lines.push(currentLine.join(" "));
        }
        currentLine = [str];
        lastY = y;
      } else {
        currentLine.push(str);
      }
    }
    if (currentLine.length > 0) {
      lines.push(currentLine.join(" "));
    }

    textParts.push(lines.join("\n"));
  }

  return {
    text: cleanText(textParts.join("\n\n")),
    pageCount: pdf.numPages,
  };
}

async function parseDOCX(file: File): Promise<ParseResult> {
  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer });
  const text = cleanText(result.value);
  // Estimate pages for DOCX (~3000 chars per page)
  const pageCount = Math.max(1, Math.round(text.length / 3000));
  return { text, pageCount };
}

function cleanText(text: string): string {
  return text
    .replace(/[^\w\s@.+#/\-(),&|:\n]/g, " ") // keep colons and newlines
    .replace(/[ \t]+/g, " ") // collapse horizontal whitespace only
    .replace(/\n{3,}/g, "\n\n") // max 2 consecutive newlines
    .trim()
    .toLowerCase();
}

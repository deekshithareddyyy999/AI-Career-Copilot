export type DemandLevel = "high" | "moderate" | "emerging";

export interface DemandSkill {
  name: string;
  level: DemandLevel;
  growthPercent: number; // YoY growth %
  description: string;
}

export const JOB_MARKET_DATA: Record<string, DemandSkill[]> = {
  "Data Analyst": [
    { name: "SQL", level: "high", growthPercent: 35, description: "Core querying language for data extraction and manipulation" },
    { name: "Python", level: "high", growthPercent: 42, description: "Primary language for data analysis and automation" },
    { name: "Power BI", level: "high", growthPercent: 38, description: "Leading enterprise business intelligence tool" },
    { name: "Tableau", level: "high", growthPercent: 30, description: "Industry-standard data visualization platform" },
    { name: "Excel (Advanced)", level: "moderate", growthPercent: 15, description: "Pivot tables, VLOOKUP, macros for business analysis" },
    { name: "R Programming", level: "moderate", growthPercent: 12, description: "Statistical computing and data visualization" },
    { name: "Google Looker", level: "moderate", growthPercent: 22, description: "Cloud-based BI and analytics platform" },
    { name: "dbt (Data Build Tool)", level: "emerging", growthPercent: 65, description: "Analytics engineering and data transformation" },
    { name: "Apache Spark", level: "emerging", growthPercent: 48, description: "Big data processing for large-scale analytics" },
    { name: "AI-Assisted Analytics", level: "emerging", growthPercent: 85, description: "Using AI tools for automated insights generation" },
  ],
  "Data Scientist": [
    { name: "Python", level: "high", growthPercent: 45, description: "Primary language for ML and data science workflows" },
    { name: "TensorFlow / PyTorch", level: "high", growthPercent: 50, description: "Leading deep learning frameworks" },
    { name: "Machine Learning", level: "high", growthPercent: 40, description: "Core ML algorithms and model building" },
    { name: "Statistics & Probability", level: "high", growthPercent: 25, description: "Foundation for hypothesis testing and modeling" },
    { name: "NLP", level: "moderate", growthPercent: 38, description: "Text analysis, sentiment analysis, language models" },
    { name: "Computer Vision", level: "moderate", growthPercent: 35, description: "Image classification, object detection pipelines" },
    { name: "MLOps", level: "moderate", growthPercent: 55, description: "Model deployment, monitoring, and lifecycle management" },
    { name: "LLM Fine-Tuning", level: "emerging", growthPercent: 120, description: "Customizing large language models for domain tasks" },
    { name: "Generative AI", level: "emerging", growthPercent: 150, description: "Building applications with generative models" },
    { name: "Responsible AI", level: "emerging", growthPercent: 70, description: "Fairness, explainability, and bias mitigation" },
  ],
  "AI Engineer": [
    { name: "Python", level: "high", growthPercent: 48, description: "Core language for AI application development" },
    { name: "LangChain / LlamaIndex", level: "high", growthPercent: 180, description: "Frameworks for building LLM-powered applications" },
    { name: "Prompt Engineering", level: "high", growthPercent: 200, description: "Designing effective prompts for AI models" },
    { name: "RAG Systems", level: "high", growthPercent: 160, description: "Retrieval-augmented generation architectures" },
    { name: "Vector Databases", level: "moderate", growthPercent: 130, description: "Pinecone, Weaviate, ChromaDB for embeddings" },
    { name: "API Development", level: "moderate", growthPercent: 30, description: "REST/GraphQL APIs for AI service integration" },
    { name: "Docker & Kubernetes", level: "moderate", growthPercent: 28, description: "Containerization for AI model deployment" },
    { name: "AI Agents", level: "emerging", growthPercent: 250, description: "Autonomous AI agents with tool-use capabilities" },
    { name: "Multi-Modal AI", level: "emerging", growthPercent: 140, description: "Combining text, image, audio in AI systems" },
    { name: "Edge AI", level: "emerging", growthPercent: 90, description: "Deploying AI models on edge devices" },
  ],
  "ML Engineer": [
    { name: "Python", level: "high", growthPercent: 44, description: "Primary language for ML pipeline development" },
    { name: "TensorFlow / PyTorch", level: "high", growthPercent: 46, description: "Building and training neural network models" },
    { name: "MLOps (MLflow, Kubeflow)", level: "high", growthPercent: 65, description: "End-to-end ML pipeline orchestration" },
    { name: "Cloud ML Services", level: "high", growthPercent: 55, description: "AWS SageMaker, GCP Vertex AI, Azure ML" },
    { name: "Feature Engineering", level: "moderate", growthPercent: 30, description: "Creating optimal features for model training" },
    { name: "Model Optimization", level: "moderate", growthPercent: 40, description: "Quantization, pruning, distillation techniques" },
    { name: "Data Pipelines", level: "moderate", growthPercent: 35, description: "Apache Airflow, Prefect for workflow automation" },
    { name: "Real-Time ML", level: "emerging", growthPercent: 80, description: "Streaming inference and online learning" },
    { name: "Federated Learning", level: "emerging", growthPercent: 95, description: "Privacy-preserving distributed training" },
    { name: "AutoML", level: "emerging", growthPercent: 60, description: "Automated model selection and hyperparameter tuning" },
  ],
  "Software Engineer": [
    { name: "JavaScript / TypeScript", level: "high", growthPercent: 35, description: "Dominant languages for web development" },
    { name: "React", level: "high", growthPercent: 32, description: "Leading frontend framework for UI development" },
    { name: "Node.js", level: "high", growthPercent: 28, description: "Server-side JavaScript runtime" },
    { name: "Cloud (AWS/GCP/Azure)", level: "high", growthPercent: 40, description: "Cloud infrastructure and services" },
    { name: "Docker", level: "moderate", growthPercent: 30, description: "Containerization for consistent deployments" },
    { name: "CI/CD Pipelines", level: "moderate", growthPercent: 25, description: "Automated testing and deployment workflows" },
    { name: "System Design", level: "moderate", growthPercent: 35, description: "Designing scalable distributed systems" },
    { name: "Rust", level: "emerging", growthPercent: 75, description: "High-performance systems programming language" },
    { name: "AI-Assisted Coding", level: "emerging", growthPercent: 200, description: "GitHub Copilot, Cursor, AI pair programming" },
    { name: "WebAssembly", level: "emerging", growthPercent: 55, description: "Near-native performance in the browser" },
  ],
  "Full Stack Developer": [
    { name: "React / Next.js", level: "high", growthPercent: 38, description: "Frontend framework with SSR capabilities" },
    { name: "Node.js / Express", level: "high", growthPercent: 30, description: "Backend server and API development" },
    { name: "PostgreSQL", level: "high", growthPercent: 33, description: "Advanced relational database for production apps" },
    { name: "TypeScript", level: "high", growthPercent: 45, description: "Type-safe JavaScript for full-stack development" },
    { name: "Tailwind CSS", level: "moderate", growthPercent: 50, description: "Utility-first CSS framework for rapid UI" },
    { name: "GraphQL", level: "moderate", growthPercent: 28, description: "Flexible API query language" },
    { name: "Redis", level: "moderate", growthPercent: 22, description: "In-memory caching and session management" },
    { name: "tRPC", level: "emerging", growthPercent: 85, description: "End-to-end typesafe APIs without schemas" },
    { name: "Serverless / Edge Functions", level: "emerging", growthPercent: 60, description: "Deploying functions at the edge for low latency" },
    { name: "AI Integration", level: "emerging", growthPercent: 180, description: "Adding AI features to full-stack applications" },
  ],
};

export const DEMAND_LEVEL_CONFIG: Record<DemandLevel, { label: string; color: string; bgColor: string; borderColor: string }> = {
  high: { label: "High Demand", color: "text-emerald-400", bgColor: "bg-emerald-500/15", borderColor: "border-emerald-500/30" },
  moderate: { label: "Moderate Demand", color: "text-amber-400", bgColor: "bg-amber-500/15", borderColor: "border-amber-500/30" },
  emerging: { label: "Emerging Skill", color: "text-violet-400", bgColor: "bg-violet-500/15", borderColor: "border-violet-500/30" },
};

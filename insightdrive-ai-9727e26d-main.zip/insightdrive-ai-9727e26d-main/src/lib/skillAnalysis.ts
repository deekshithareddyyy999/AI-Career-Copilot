import type { ExtractedSkill } from "./skillExtractor";
import type { SkillItem, RoleComparison } from "./mockData";

interface RoleRequirements {
  required: string[];
  preferred: string[];
  weights: Record<string, number>; // skill name -> importance weight (0-1)
}

const ROLE_REQUIREMENTS: Record<string, RoleRequirements> = {
  "data analyst": {
    required: ["SQL", "Excel", "Data Visualization", "Statistics", "Python"],
    preferred: ["Tableau", "Power BI", "A/B Testing", "Communication", "Pandas", "R", "ETL", "Project Management"],
    weights: {
      SQL: 1, Excel: 0.8, "Data Visualization": 0.9, Statistics: 0.9, Python: 0.8,
      Tableau: 0.7, "Power BI": 0.7, "A/B Testing": 0.6, Communication: 0.5, Pandas: 0.6,
      R: 0.5, ETL: 0.5, "Project Management": 0.4,
    },
  },
  "data scientist": {
    required: ["Python", "SQL", "Statistics", "Scikit-learn", "Pandas", "NumPy"],
    preferred: ["Deep Learning", "TensorFlow", "PyTorch", "NLP", "Data Visualization", "MLOps", "AWS", "GCP", "A/B Testing", "R", "Mathematics"],
    weights: {
      Python: 1, SQL: 0.8, Statistics: 0.9, "Scikit-learn": 0.9, Pandas: 0.8, NumPy: 0.8,
      "Deep Learning": 0.7, TensorFlow: 0.6, PyTorch: 0.6, NLP: 0.5, "Data Visualization": 0.6,
      MLOps: 0.5, AWS: 0.4, GCP: 0.4, "A/B Testing": 0.5, R: 0.5, Mathematics: 0.6,
    },
  },
  "ai engineer": {
    required: ["Python", "Deep Learning", "LLMs & Prompt Engineering", "TensorFlow", "PyTorch"],
    preferred: ["NLP", "Computer Vision", "MLOps", "Docker", "Kubernetes", "AWS", "GCP", "FastAPI", "Vector Databases", "Git", "CI/CD", "Reinforcement Learning"],
    weights: {
      Python: 1, "Deep Learning": 1, "LLMs & Prompt Engineering": 1, TensorFlow: 0.8, PyTorch: 0.8,
      NLP: 0.7, "Computer Vision": 0.6, MLOps: 0.7, Docker: 0.6, Kubernetes: 0.5,
      AWS: 0.5, GCP: 0.5, FastAPI: 0.5, "Vector Databases": 0.6, Git: 0.4, "CI/CD": 0.4,
      "Reinforcement Learning": 0.4,
    },
  },
  "ml engineer": {
    required: ["Python", "Scikit-learn", "Deep Learning", "Docker", "SQL"],
    preferred: ["PyTorch", "TensorFlow", "MLOps", "Kubernetes", "AWS", "GCP", "Apache Spark", "CI/CD", "Git", "FastAPI", "Linux", "Mathematics"],
    weights: {
      Python: 1, "Scikit-learn": 0.9, "Deep Learning": 0.9, Docker: 0.8, SQL: 0.7,
      PyTorch: 0.7, TensorFlow: 0.7, MLOps: 0.8, Kubernetes: 0.6, AWS: 0.5,
      GCP: 0.5, "Apache Spark": 0.5, "CI/CD": 0.5, Git: 0.4, FastAPI: 0.5, Linux: 0.4, Mathematics: 0.5,
    },
  },
  "frontend developer": {
    required: ["JavaScript", "TypeScript", "React", "Git"],
    preferred: ["Node.js", "Docker", "CI/CD", "Linux", "Communication"],
    weights: {
      JavaScript: 1, TypeScript: 0.9, React: 1, Git: 0.7,
      "Node.js": 0.6, Docker: 0.4, "CI/CD": 0.4, Linux: 0.3, Communication: 0.3,
    },
  },
  "software engineer": {
    required: ["JavaScript", "TypeScript", "Python", "SQL", "Git"],
    preferred: ["React", "Node.js", "Docker", "Kubernetes", "CI/CD", "AWS", "PostgreSQL", "MongoDB", "Redis", "Linux", "Java", "Go", "FastAPI", "Communication"],
    weights: {
      JavaScript: 0.9, TypeScript: 0.9, Python: 0.9, SQL: 0.8, Git: 0.8,
      React: 0.7, "Node.js": 0.8, Docker: 0.7, Kubernetes: 0.5, "CI/CD": 0.6,
      AWS: 0.6, PostgreSQL: 0.7, MongoDB: 0.5, Redis: 0.4, Linux: 0.5,
      Java: 0.5, Go: 0.4, FastAPI: 0.4, Communication: 0.4,
    },
  },
  "product manager": {
    required: ["Communication", "Project Management", "A/B Testing", "SQL"],
    preferred: ["Data Visualization", "Statistics", "Excel", "Python", "Leadership", "Tableau"],
    weights: {
      Communication: 1, "Project Management": 1, "A/B Testing": 0.8, SQL: 0.6,
      "Data Visualization": 0.5, Statistics: 0.5, Excel: 0.5, Python: 0.4, Leadership: 0.7, Tableau: 0.4,
    },
  },
};

function normalizeRole(role: string): string {
  const r = role.toLowerCase().trim();
  const aliases: Record<string, string> = {
    "machine learning engineer": "ml engineer",
    "ml": "ml engineer",
    "data science": "data scientist",
    "ds": "data scientist",
    "analyst": "data analyst",
    "ai": "ai engineer",
    "artificial intelligence engineer": "ai engineer",
    "frontend": "frontend developer",
    "front end developer": "frontend developer",
    "swe": "software engineer",
    "sde": "software engineer",
    "backend developer": "software engineer",
    "full stack developer": "software engineer",
    "fullstack developer": "software engineer",
    "software developer": "software engineer",
    "pm": "product manager",
  };
  if (ROLE_REQUIREMENTS[r]) return r;
  for (const [alias, canonical] of Object.entries(aliases)) {
    if (r.includes(alias)) return canonical;
  }
  for (const key of Object.keys(ROLE_REQUIREMENTS)) {
    if (r.includes(key) || key.includes(r)) return key;
  }
  return "data scientist"; // fallback
}

export interface AnalysisResult {
  targetRole: string;
  readinessScore: number;
  detectedSkills: SkillItem[];
  missingSkills: SkillItem[];
  roleComparison: RoleComparison[];
  extractedText: string;
}

export function analyzeSkillGap(
  extractedSkills: ExtractedSkill[],
  targetRole: string,
  resumeText: string
): AnalysisResult {
  const normalizedRole = normalizeRole(targetRole);
  const requirements = ROLE_REQUIREMENTS[normalizedRole];
  const extractedNames = new Set(extractedSkills.map((s) => s.name));

  // Detected skills (matching role requirements)
  const allRoleSkills = [...requirements.required, ...requirements.preferred];
  const detectedSkills: SkillItem[] = [];
  const missingSkills: SkillItem[] = [];

  for (const skillName of allRoleSkills) {
    const extracted = extractedSkills.find((s) => s.name === skillName);
    if (extracted) {
      const isRequired = requirements.required.includes(skillName);
      detectedSkills.push({
        name: skillName,
        level: extracted.confidence === "high" ? "strong" : "moderate",
        category: extracted.category,
      });
    } else {
      const cat = extractedSkills.find((s) => s.category)?.category || "General";
      missingSkills.push({
        name: skillName,
        level: "missing",
        category: getSkillCategory(skillName),
      });
    }
  }

  // Add extra detected skills not in role requirements
  for (const skill of extractedSkills) {
    if (!allRoleSkills.includes(skill.name)) {
      detectedSkills.push({
        name: skill.name,
        level: skill.confidence === "high" ? "strong" : "moderate",
        category: skill.category,
      });
    }
  }

  // Calculate readiness score
  let totalWeight = 0;
  let earnedWeight = 0;
  for (const [skill, weight] of Object.entries(requirements.weights)) {
    totalWeight += weight;
    if (extractedNames.has(skill)) {
      const confidence = extractedSkills.find((s) => s.name === skill)?.confidence;
      earnedWeight += weight * (confidence === "high" ? 1 : 0.7);
    }
  }
  const readinessScore = Math.round((earnedWeight / totalWeight) * 100);

  // Role comparison across all roles
  const roleComparison: RoleComparison[] = Object.entries(ROLE_REQUIREMENTS).map(
    ([role, reqs]) => {
      let tw = 0;
      let ew = 0;
      for (const [skill, weight] of Object.entries(reqs.weights)) {
        tw += weight;
        if (extractedNames.has(skill)) {
          const conf = extractedSkills.find((s) => s.name === skill)?.confidence;
          ew += weight * (conf === "high" ? 1 : 0.7);
        }
      }
      return {
        role: role.split(" ").map((w) => w[0].toUpperCase() + w.slice(1)).join(" "),
        score: Math.round((ew / tw) * 100),
      };
    }
  );

  // Sort by score descending
  roleComparison.sort((a, b) => b.score - a.score);

  return {
    targetRole,
    readinessScore,
    detectedSkills,
    missingSkills,
    roleComparison: roleComparison.slice(0, 4),
    extractedText: resumeText,
  };
}

function getSkillCategory(skillName: string): string {
  const categoryMap: Record<string, string> = {
    Python: "Programming", JavaScript: "Programming", TypeScript: "Programming",
    SQL: "Data", Pandas: "Data", NumPy: "Data", Excel: "Data",
    TensorFlow: "AI/ML", PyTorch: "AI/ML", "Scikit-learn": "AI/ML",
    "Deep Learning": "AI/ML", NLP: "AI/ML", "Computer Vision": "AI/ML",
    MLOps: "AI/ML", "LLMs & Prompt Engineering": "AI/ML",
    AWS: "Cloud", GCP: "Cloud", Azure: "Cloud",
    Docker: "DevOps", Kubernetes: "DevOps", "CI/CD": "DevOps",
    Git: "Tools", Linux: "Tools",
    Statistics: "Math", Mathematics: "Math", "A/B Testing": "Analytics",
    Communication: "Soft Skills", "Project Management": "Soft Skills",
    Leadership: "Soft Skills", "Data Visualization": "Data",
    Tableau: "Data", "Power BI": "Data", React: "Frameworks",
    "Node.js": "Frameworks", FastAPI: "Frameworks",
    "Vector Databases": "Databases", "Reinforcement Learning": "AI/ML",
    "Apache Spark": "Data", ETL: "Data", R: "Programming",
    MongoDB: "Databases", PostgreSQL: "Databases", Redis: "Databases",
    Elasticsearch: "Databases",
  };
  return categoryMap[skillName] || "General";
}

export function getRoleRequirements() {
  return ROLE_REQUIREMENTS;
}

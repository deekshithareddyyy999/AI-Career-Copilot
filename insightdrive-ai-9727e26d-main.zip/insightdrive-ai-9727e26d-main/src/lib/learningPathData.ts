export interface LearningSkill {
  name: string;
  description: string;
  resource?: string;
  resourceUrl?: string;
}

export interface LevelSkills {
  beginner: LearningSkill[];
  intermediate: LearningSkill[];
  advanced: LearningSkill[];
}

export const LEARNING_PATHS: Record<string, LevelSkills> = {
  "Data Analyst": {
    beginner: [
      { name: "Python Basics", description: "Variables, loops, functions, data types", resource: "Python.org Tutorial (Free)", resourceUrl: "https://docs.python.org/3/tutorial/" },
      { name: "Statistics Fundamentals", description: "Mean, median, mode, standard deviation", resource: "Khan Academy (Free)", resourceUrl: "https://www.khanacademy.org/math/statistics-probability" },
      { name: "SQL Basics", description: "SELECT, WHERE, JOIN, GROUP BY", resource: "SQLBolt (Free)", resourceUrl: "https://sqlbolt.com/" },
      { name: "Excel / Google Sheets", description: "Formulas, pivot tables, VLOOKUP", resource: "Google Sheets Training (Free)", resourceUrl: "https://support.google.com/a/users/answer/9282959" },
      { name: "Data Visualization Basics", description: "Charts, graphs, storytelling with data", resource: "Google Data Analytics – Coursera (Free to audit)", resourceUrl: "https://www.coursera.org/professional-certificates/google-data-analytics" },
      { name: "R Programming", description: "Basics of R for data analysis, vectors, data frames", resource: "R for Data Science (Free)", resourceUrl: "https://r4ds.had.co.nz/" },
      { name: "Data Cleaning", description: "Handling missing values, duplicates, formatting", resource: "Kaggle Data Cleaning (Free)", resourceUrl: "https://www.kaggle.com/learn/data-cleaning" },
    ],
    intermediate: [
      { name: "Pandas & NumPy", description: "DataFrames, array operations, data wrangling", resource: "Kaggle Pandas Course (Free)", resourceUrl: "https://www.kaggle.com/learn/pandas" },
      { name: "Advanced SQL", description: "Window functions, CTEs, subqueries", resource: "Mode SQL Tutorial (Free)", resourceUrl: "https://mode.com/sql-tutorial/" },
      { name: "Power BI / Tableau", description: "Interactive dashboards, DAX, calculated fields", resource: "Tableau Public Learn (Free)", resourceUrl: "https://public.tableau.com/app/learn" },
      { name: "Exploratory Data Analysis", description: "Distributions, correlations, outlier detection", resource: "Kaggle Data Viz Course (Free)", resourceUrl: "https://www.kaggle.com/learn/data-visualization" },
      { name: "A/B Testing", description: "Hypothesis testing, p-values, experiment design", resource: "Google A/B Testing – Udacity (Free)", resourceUrl: "https://www.udacity.com/course/ab-testing--ud257" },
      { name: "Looker / Google Data Studio", description: "Building reports, data blending, sharing dashboards", resource: "Google Looker Studio (Free)", resourceUrl: "https://lookerstudio.google.com/" },
      { name: "Web Scraping", description: "BeautifulSoup, Scrapy, collecting web data", resource: "Real Python Web Scraping (Free)", resourceUrl: "https://realpython.com/beautiful-soup-web-scraper-python/" },
      { name: "Regular Expressions", description: "Pattern matching for data extraction and cleaning", resource: "RegexOne (Free)", resourceUrl: "https://regexone.com/" },
    ],
    advanced: [
      { name: "Machine Learning for Analysts", description: "Regression, classification, clustering basics", resource: "Scikit-learn Docs", resourceUrl: "https://scikit-learn.org/stable/tutorial/" },
      { name: "Big Data Tools", description: "Spark, Hadoop fundamentals", resource: "Apache Spark Docs", resourceUrl: "https://spark.apache.org/docs/latest/" },
      { name: "Data Pipeline & ETL", description: "Airflow, dbt, data warehousing", resource: "dbt Learn", resourceUrl: "https://courses.getdbt.com/" },
      { name: "Cloud Analytics", description: "BigQuery, Redshift, Snowflake", resource: "Google BigQuery Docs", resourceUrl: "https://cloud.google.com/bigquery/docs" },
      { name: "Data Governance & Ethics", description: "Data quality, privacy, compliance", resource: "DAMA International", resourceUrl: "https://www.dama.org/" },
      { name: "Time Series Analysis", description: "Forecasting, ARIMA, seasonal decomposition", resource: "Statsmodels Docs (Free)", resourceUrl: "https://www.statsmodels.org/stable/tsa.html" },
      { name: "Geospatial Analysis", description: "Maps, GIS, spatial data with Python", resource: "GeoPandas Docs (Free)", resourceUrl: "https://geopandas.org/en/stable/" },
    ],
  },
  "Data Scientist": {
    beginner: [
      { name: "Python Basics", description: "Variables, loops, functions, OOP", resource: "Python.org Tutorial (Free)", resourceUrl: "https://docs.python.org/3/tutorial/" },
      { name: "Statistics Fundamentals", description: "Probability, distributions, hypothesis testing", resource: "Khan Academy (Free)", resourceUrl: "https://www.khanacademy.org/math/statistics-probability" },
      { name: "SQL Basics", description: "Querying, filtering, aggregation", resource: "SQLBolt (Free)", resourceUrl: "https://sqlbolt.com/" },
      { name: "Excel", description: "Data manipulation, formulas, charts", resource: "GCF Excel Tutorial (Free)", resourceUrl: "https://edu.gcfglobal.org/en/excel/" },
      { name: "Data Visualization", description: "Matplotlib, Seaborn basics", resource: "Matplotlib Official Tutorials (Free)", resourceUrl: "https://matplotlib.org/stable/tutorials/" },
      { name: "Jupyter Notebooks", description: "Interactive coding, markdown, inline visualization", resource: "Jupyter Docs (Free)", resourceUrl: "https://jupyter.org/try" },
      { name: "Linear Algebra Basics", description: "Vectors, matrices, dot products", resource: "3Blue1Brown – YouTube (Free)", resourceUrl: "https://www.youtube.com/playlist?list=PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab" },
    ],
    intermediate: [
      { name: "Machine Learning Algorithms", description: "Linear/logistic regression, trees, SVM, KNN", resource: "Andrew Ng ML – Coursera (Free to audit)", resourceUrl: "https://www.coursera.org/learn/machine-learning" },
      { name: "Feature Engineering", description: "Encoding, scaling, feature selection", resource: "Kaggle Feature Engineering (Free)", resourceUrl: "https://www.kaggle.com/learn/feature-engineering" },
      { name: "Data Preprocessing", description: "Cleaning, imputation, transformation", resource: "Kaggle Data Cleaning (Free)", resourceUrl: "https://www.kaggle.com/learn/data-cleaning" },
      { name: "Model Evaluation", description: "Cross-validation, metrics, bias-variance tradeoff", resource: "Scikit-learn Docs (Free)", resourceUrl: "https://scikit-learn.org/stable/modules/model_evaluation.html" },
      { name: "Power BI / Tableau", description: "Dashboarding, visual analytics", resource: "Tableau Public Learn (Free)", resourceUrl: "https://public.tableau.com/app/learn" },
      { name: "Natural Language Processing", description: "Text preprocessing, TF-IDF, sentiment analysis", resource: "NLTK Book (Free)", resourceUrl: "https://www.nltk.org/book/" },
      { name: "Time Series Forecasting", description: "ARIMA, Prophet, seasonal patterns", resource: "Facebook Prophet Docs (Free)", resourceUrl: "https://facebook.github.io/prophet/" },
      { name: "Bayesian Statistics", description: "Prior/posterior, Bayesian inference, PyMC", resource: "Bayesian Methods for Hackers (Free)", resourceUrl: "https://camdavidsonpilon.github.io/Probabilistic-Programming-and-Bayesian-Methods-for-Hackers/" },
    ],
    advanced: [
      { name: "Deep Learning", description: "Neural networks, CNNs, RNNs, Transformers", resource: "Deep Learning Book", resourceUrl: "https://www.deeplearningbook.org/" },
      { name: "Model Deployment", description: "Flask/FastAPI serving, Docker, REST APIs", resource: "FastAPI Docs", resourceUrl: "https://fastapi.tiangolo.com/" },
      { name: "MLOps", description: "MLflow, experiment tracking, CI/CD for ML", resource: "MLflow Docs", resourceUrl: "https://mlflow.org/docs/latest/" },
      { name: "Cloud AI Services", description: "AWS SageMaker, GCP Vertex AI, Azure ML", resource: "AWS SageMaker", resourceUrl: "https://docs.aws.amazon.com/sagemaker/" },
      { name: "Large Language Models", description: "LLM fine-tuning, prompt engineering, RAG", resource: "Hugging Face", resourceUrl: "https://huggingface.co/docs" },
      { name: "Reinforcement Learning", description: "Q-learning, policy gradients, OpenAI Gym", resource: "Spinning Up in RL (Free)", resourceUrl: "https://spinningup.openai.com/" },
      { name: "Causal Inference", description: "A/B tests, propensity scores, causal graphs", resource: "Causal Inference Book (Free)", resourceUrl: "https://www.hsph.harvard.edu/miguel-hernan/causal-inference-book/" },
    ],
  },
  "AI Engineer": {
    beginner: [
      { name: "Python Programming", description: "Core Python, OOP, file handling", resource: "Python.org Tutorial (Free)", resourceUrl: "https://docs.python.org/3/tutorial/" },
      { name: "Linear Algebra", description: "Vectors, matrices, eigenvalues", resource: "3Blue1Brown – YouTube (Free)", resourceUrl: "https://www.youtube.com/playlist?list=PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab" },
      { name: "Probability & Statistics", description: "Bayes theorem, distributions", resource: "Khan Academy (Free)", resourceUrl: "https://www.khanacademy.org/math/statistics-probability" },
      { name: "NumPy & Pandas", description: "Array operations, data manipulation", resource: "Kaggle Pandas Course (Free)", resourceUrl: "https://www.kaggle.com/learn/pandas" },
      { name: "Git & Version Control", description: "Branching, merging, collaboration", resource: "Pro Git Book (Free)", resourceUrl: "https://git-scm.com/book/en/v2" },
      { name: "Jupyter & Colab", description: "Interactive notebooks, GPU access", resource: "Google Colab (Free)", resourceUrl: "https://colab.research.google.com/" },
      { name: "Calculus for ML", description: "Derivatives, gradients, chain rule", resource: "3Blue1Brown Calculus (Free)", resourceUrl: "https://www.youtube.com/playlist?list=PLZHQObOWTQDMsr9K-rj53DwVRMYO3t5Yr" },
    ],
    intermediate: [
      { name: "Deep Learning Frameworks", description: "PyTorch, TensorFlow, model building", resource: "PyTorch Official Tutorials (Free)", resourceUrl: "https://pytorch.org/tutorials/" },
      { name: "NLP Fundamentals", description: "Tokenization, embeddings, text classification", resource: "Hugging Face NLP Course (Free)", resourceUrl: "https://huggingface.co/learn/nlp-course/" },
      { name: "Computer Vision", description: "CNNs, object detection, image segmentation", resource: "CS231n Stanford (Free)", resourceUrl: "https://cs231n.stanford.edu/" },
      { name: "Model Training & Optimization", description: "Hyperparameter tuning, regularization", resource: "Fast.ai (Free)", resourceUrl: "https://course.fast.ai/" },
      { name: "API Development", description: "FastAPI, REST endpoints, authentication", resource: "FastAPI Docs (Free)", resourceUrl: "https://fastapi.tiangolo.com/" },
      { name: "Hugging Face Transformers", description: "Pre-trained models, pipelines, fine-tuning", resource: "HF Transformers Docs (Free)", resourceUrl: "https://huggingface.co/docs/transformers/" },
      { name: "Speech & Audio AI", description: "ASR, TTS, Whisper, audio classification", resource: "Hugging Face Audio Course (Free)", resourceUrl: "https://huggingface.co/learn/audio-course/" },
      { name: "Docker & Containers", description: "Containerizing AI applications", resource: "Docker Get Started (Free)", resourceUrl: "https://docs.docker.com/get-started/" },
    ],
    advanced: [
      { name: "LLM Engineering", description: "Fine-tuning, RLHF, prompt engineering", resource: "Hugging Face", resourceUrl: "https://huggingface.co/docs" },
      { name: "RAG & Vector Databases", description: "Retrieval augmented generation, Pinecone, Weaviate", resource: "LangChain Docs", resourceUrl: "https://python.langchain.com/docs/" },
      { name: "AI System Design", description: "Scalable AI pipelines, microservices", resource: "Designing ML Systems", resourceUrl: "https://www.oreilly.com/library/view/designing-machine-learning/9781098107956/" },
      { name: "Edge AI & Optimization", description: "Model quantization, ONNX, TensorRT", resource: "ONNX Docs", resourceUrl: "https://onnx.ai/" },
      { name: "AI Ethics & Safety", description: "Responsible AI, bias mitigation, alignment", resource: "AI Ethics Guidelines", resourceUrl: "https://www.microsoft.com/en-us/ai/responsible-ai" },
      { name: "Multi-Modal AI", description: "Vision-language models, CLIP, GPT-4V", resource: "OpenAI API Docs", resourceUrl: "https://platform.openai.com/docs/" },
      { name: "AI Agents & Autonomous Systems", description: "Agent frameworks, tool use, planning", resource: "LangGraph Docs", resourceUrl: "https://langchain-ai.github.io/langgraph/" },
      { name: "Diffusion Models", description: "Stable Diffusion, image generation, LoRA", resource: "Stability AI Docs", resourceUrl: "https://stability.ai/" },
    ],
  },
  "Machine Learning Engineer": {
    beginner: [
      { name: "Python Programming", description: "Data structures, OOP, libraries", resource: "Python.org Tutorial (Free)", resourceUrl: "https://docs.python.org/3/tutorial/" },
      { name: "Mathematics for ML", description: "Linear algebra, calculus, probability", resource: "Mathematics for ML Book (Free)", resourceUrl: "https://mml-book.github.io/" },
      { name: "SQL & Databases", description: "Relational databases, querying", resource: "SQLBolt (Free)", resourceUrl: "https://sqlbolt.com/" },
      { name: "Scikit-learn Basics", description: "Classification, regression, pipelines", resource: "Scikit-learn Tutorials (Free)", resourceUrl: "https://scikit-learn.org/stable/tutorial/" },
      { name: "Git & CLI Tools", description: "Version control, terminal commands", resource: "Pro Git Book (Free)", resourceUrl: "https://git-scm.com/book/en/v2" },
      { name: "Data Preprocessing", description: "Cleaning, normalization, encoding", resource: "Kaggle Data Cleaning (Free)", resourceUrl: "https://www.kaggle.com/learn/data-cleaning" },
      { name: "Jupyter Notebooks", description: "Interactive development, experimentation", resource: "Jupyter Docs (Free)", resourceUrl: "https://jupyter.org/try" },
    ],
    intermediate: [
      { name: "Deep Learning", description: "Neural networks, backpropagation, architectures", resource: "Deep Learning Book (Free)", resourceUrl: "https://www.deeplearningbook.org/" },
      { name: "PyTorch / TensorFlow", description: "Model building, training loops, GPU usage", resource: "PyTorch Official Tutorials (Free)", resourceUrl: "https://pytorch.org/tutorials/" },
      { name: "Feature Engineering", description: "Feature stores, automated feature selection", resource: "Kaggle Feature Engineering (Free)", resourceUrl: "https://www.kaggle.com/learn/feature-engineering" },
      { name: "Docker & Containers", description: "Containerization, Docker Compose", resource: "Docker Get Started (Free)", resourceUrl: "https://docs.docker.com/get-started/" },
      { name: "Data Pipelines", description: "Apache Airflow, ETL, batch processing", resource: "Airflow Official Docs (Free)", resourceUrl: "https://airflow.apache.org/docs/" },
      { name: "Experiment Tracking", description: "Weights & Biases, MLflow logging", resource: "W&B Docs (Free tier)", resourceUrl: "https://docs.wandb.ai/" },
      { name: "Model Optimization", description: "Hyperparameter tuning, Optuna, grid search", resource: "Optuna Docs (Free)", resourceUrl: "https://optuna.readthedocs.io/" },
      { name: "Streaming Data", description: "Kafka, real-time data processing", resource: "Apache Kafka Docs (Free)", resourceUrl: "https://kafka.apache.org/documentation/" },
    ],
    advanced: [
      { name: "MLOps & CI/CD", description: "MLflow, Kubeflow, automated retraining", resource: "MLflow Docs", resourceUrl: "https://mlflow.org/docs/latest/" },
      { name: "Distributed Training", description: "Multi-GPU, Horovod, DeepSpeed", resource: "DeepSpeed Docs", resourceUrl: "https://www.deepspeed.ai/" },
      { name: "Model Serving", description: "TensorFlow Serving, Triton, BentoML", resource: "BentoML Docs", resourceUrl: "https://docs.bentoml.com/" },
      { name: "Kubernetes for ML", description: "K8s orchestration, scaling ML workloads", resource: "Kubernetes Docs", resourceUrl: "https://kubernetes.io/docs/home/" },
      { name: "Cloud ML Platforms", description: "SageMaker, Vertex AI, Azure ML pipelines", resource: "AWS SageMaker", resourceUrl: "https://docs.aws.amazon.com/sagemaker/" },
      { name: "Feature Stores", description: "Feast, Tecton, online/offline feature serving", resource: "Feast Docs (Free)", resourceUrl: "https://docs.feast.dev/" },
      { name: "Model Monitoring", description: "Data drift detection, model performance tracking", resource: "Evidently AI (Free)", resourceUrl: "https://www.evidentlyai.com/" },
      { name: "Graph Neural Networks", description: "GNNs, PyG, node/edge prediction", resource: "PyG Docs (Free)", resourceUrl: "https://pytorch-geometric.readthedocs.io/" },
    ],
  },
  "Software Engineer": {
    beginner: [
      { name: "HTML, CSS & JavaScript", description: "Web fundamentals, DOM manipulation", resource: "MDN Web Docs (Free)", resourceUrl: "https://developer.mozilla.org/en-US/docs/Learn" },
      { name: "Git & GitHub", description: "Version control, pull requests, branching", resource: "Pro Git Book (Free)", resourceUrl: "https://git-scm.com/book/en/v2" },
      { name: "Data Structures", description: "Arrays, linked lists, stacks, queues, trees", resource: "freeCodeCamp DS & Algo (Free)", resourceUrl: "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures-v8/" },
      { name: "Algorithms", description: "Sorting, searching, recursion, Big O", resource: "NeetCode (Free)", resourceUrl: "https://neetcode.io/" },
      { name: "Command Line & OS Basics", description: "Terminal, file systems, processes", resource: "Linux Journey (Free)", resourceUrl: "https://linuxjourney.com/" },
      { name: "TypeScript", description: "Types, interfaces, generics for safer code", resource: "TypeScript Handbook (Free)", resourceUrl: "https://www.typescriptlang.org/docs/handbook/" },
      { name: "HTTP & Networking", description: "REST, HTTP methods, status codes, DNS", resource: "MDN HTTP Guide (Free)", resourceUrl: "https://developer.mozilla.org/en-US/docs/Web/HTTP" },
    ],
    intermediate: [
      { name: "React / Frontend Framework", description: "Components, state, hooks, routing", resource: "React.dev Docs (Free)", resourceUrl: "https://react.dev/learn" },
      { name: "Node.js / Backend", description: "Express, REST APIs, middleware", resource: "Node.js Learn (Free)", resourceUrl: "https://nodejs.org/en/learn" },
      { name: "Databases", description: "PostgreSQL, MongoDB, ORMs", resource: "PostgreSQL Tutorial (Free)", resourceUrl: "https://www.postgresqltutorial.com/" },
      { name: "Testing", description: "Unit, integration, E2E testing", resource: "Vitest Docs (Free)", resourceUrl: "https://vitest.dev/" },
      { name: "Docker", description: "Containers, images, Docker Compose", resource: "Docker Get Started (Free)", resourceUrl: "https://docs.docker.com/get-started/" },
      { name: "GraphQL", description: "Queries, mutations, subscriptions, Apollo", resource: "GraphQL.org Learn (Free)", resourceUrl: "https://graphql.org/learn/" },
      { name: "Redis & Caching", description: "In-memory caching, session management", resource: "Redis University (Free)", resourceUrl: "https://university.redis.com/" },
      { name: "CI/CD Basics", description: "GitHub Actions, automated builds & deploys", resource: "GitHub Actions Docs (Free)", resourceUrl: "https://docs.github.com/en/actions" },
    ],
    advanced: [
      { name: "System Design", description: "Scalability, load balancing, caching", resource: "System Design Primer", resourceUrl: "https://github.com/donnemartin/system-design-primer" },
      { name: "Cloud & DevOps", description: "AWS/GCP, CI/CD pipelines, IaC", resource: "AWS Docs", resourceUrl: "https://docs.aws.amazon.com/" },
      { name: "Microservices", description: "Service mesh, event-driven architecture", resource: "Microservices.io", resourceUrl: "https://microservices.io/" },
      { name: "Security", description: "OWASP, authentication, encryption", resource: "OWASP Top 10", resourceUrl: "https://owasp.org/www-project-top-ten/" },
      { name: "Performance Optimization", description: "Profiling, caching strategies, CDNs", resource: "web.dev (Free)", resourceUrl: "https://web.dev/performance/" },
      { name: "Kubernetes", description: "Container orchestration, pods, services, Helm", resource: "Kubernetes Docs (Free)", resourceUrl: "https://kubernetes.io/docs/home/" },
      { name: "Message Queues", description: "RabbitMQ, Kafka, async communication", resource: "RabbitMQ Tutorials (Free)", resourceUrl: "https://www.rabbitmq.com/tutorials" },
      { name: "WebSockets & Real-time", description: "Socket.io, server-sent events, live data", resource: "Socket.io Docs (Free)", resourceUrl: "https://socket.io/docs/v4/" },
    ],
  },
};
export const ROLE_OPTIONS = Object.keys(LEARNING_PATHS);
export type DifficultyLevel = "beginner" | "intermediate" | "advanced";
export type PaceLevel = "basic" | "medium" | "advanced";

import { motion } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { User, Target, Clock, TrendingUp, FileText, Calendar } from "lucide-react";
import { format } from "date-fns";

interface AnalysisRow {
  id: string;
  target_role: string;
  readiness_score: number;
  detected_skills: any;
  missing_skills: any;
  created_at: string;
}

interface ProfileRow {
  id: string;
  full_name: string | null;
  email: string | null;
  avatar_url: string | null;
  created_at: string;
}

const ProfilePage = () => {
  const { user } = useAuth();

  const { data: profile } = useQuery({
    queryKey: ["profile", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user!.id)
        .single();
      if (error) throw error;
      return data as ProfileRow;
    },
    enabled: !!user,
  });

  const { data: analyses, isLoading: analysesLoading } = useQuery({
    queryKey: ["analysis_results", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("analysis_results")
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as AnalysisRow[];
    },
    enabled: !!user,
  });

  const initials = profile?.full_name
    ? profile.full_name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
    : user?.email?.[0]?.toUpperCase() || "U";

  const totalAnalyses = analyses?.length || 0;
  const uniqueRoles = [...new Set(analyses?.map((a) => a.target_role) || [])];
  const bestScore = analyses?.length
    ? Math.max(...analyses.map((a) => a.readiness_score))
    : 0;
  const allDetectedSkills = [
    ...new Set(
      analyses?.flatMap((a) =>
        Array.isArray(a.detected_skills)
          ? a.detected_skills.map((s: any) => s.name || s)
          : []
      ) || []
    ),
  ];

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">My Profile</h1>
          <p className="text-muted-foreground">Your account overview and activity</p>
        </motion.div>

        {/* User Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-gradient-card border-border/50 shadow-card mb-8">
            <CardContent className="flex flex-col sm:flex-row items-center gap-6 p-8">
              <Avatar className="h-20 w-20 ring-2 ring-primary/30">
                <AvatarImage src={profile?.avatar_url || undefined} />
                <AvatarFallback className="bg-primary/20 text-primary text-2xl font-bold">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <div className="text-center sm:text-left flex-1">
                <h2 className="text-2xl font-bold text-foreground">
                  {profile?.full_name || "User"}
                </h2>
                <p className="text-muted-foreground">{user?.email}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  <Calendar className="inline h-3 w-3 mr-1" />
                  Joined {profile?.created_at ? format(new Date(profile.created_at), "MMM d, yyyy") : "—"}
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Stats Row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          {[
            { label: "Analyses", value: totalAnalyses, icon: FileText },
            { label: "Roles Explored", value: uniqueRoles.length, icon: Target },
            { label: "Best Score", value: `${bestScore}%`, icon: TrendingUp },
            { label: "Skills Found", value: allDetectedSkills.length, icon: User },
          ].map((stat) => (
            <Card key={stat.label} className="bg-gradient-card border-border/50 shadow-card">
              <CardContent className="p-5 text-center">
                <stat.icon className="h-5 w-5 text-primary mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {/* Roles Explored */}
        {uniqueRoles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-8"
          >
            <Card className="bg-gradient-card border-border/50 shadow-card">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  Roles Explored
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-wrap gap-2">
                {uniqueRoles.map((role) => (
                  <Badge key={role} variant="secondary" className="text-sm px-3 py-1">
                    {role}
                  </Badge>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Analysis History */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-gradient-card border-border/50 shadow-card">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                Analysis History
              </CardTitle>
            </CardHeader>
            <CardContent>
              {analysesLoading ? (
                <p className="text-muted-foreground text-sm">Loading...</p>
              ) : !analyses?.length ? (
                <p className="text-muted-foreground text-sm">
                  No analyses yet. Upload your resume to get started!
                </p>
              ) : (
                <div className="space-y-4">
                  {analyses.map((a, i) => (
                    <div key={a.id}>
                      {i > 0 && <Separator className="mb-4" />}
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-foreground">{a.target_role}</p>
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(a.created_at), "MMM d, yyyy · h:mm a")}
                          </p>
                        </div>
                        <div className="text-right">
                          <span
                            className={`text-lg font-bold ${
                              a.readiness_score >= 70
                                ? "text-primary"
                                : a.readiness_score >= 50
                                ? "text-yellow-400"
                                : "text-destructive"
                            }`}
                          >
                            {a.readiness_score}%
                          </span>
                          <p className="text-xs text-muted-foreground">Readiness</p>
                        </div>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {(Array.isArray(a.detected_skills)
                          ? a.detected_skills.slice(0, 5)
                          : []
                        ).map((s: any) => (
                          <Badge
                            key={s.name || s}
                            variant="outline"
                            className="text-xs"
                          >
                            {s.name || s}
                          </Badge>
                        ))}
                        {Array.isArray(a.detected_skills) &&
                          a.detected_skills.length > 5 && (
                            <Badge variant="outline" className="text-xs">
                              +{a.detected_skills.length - 5} more
                            </Badge>
                          )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default ProfilePage;

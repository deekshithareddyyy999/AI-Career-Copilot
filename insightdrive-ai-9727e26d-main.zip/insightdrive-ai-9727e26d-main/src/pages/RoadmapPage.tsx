import { useState } from "react";
import { motion } from "framer-motion";
import { BookOpen, Rocket, Trophy, Target, Download, CheckCircle2, Circle, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "react-router-dom";
import { getAnalysisForRole } from "@/lib/mockData";
import { generateLocalRoadmap, type GeneratedRoadmap, type RoadmapTask } from "@/lib/roadmapGenerator";
import { analyzeSkillGap } from "@/lib/skillAnalysis";
import { downloadRoadmapPDF } from "@/lib/pdfExport";
import type { AnalysisResult } from "@/lib/skillAnalysis";

const phaseIcons = [BookOpen, Rocket, Trophy, Target, BookOpen, Rocket, Trophy, Target];

const typeColors: Record<string, string> = {
  course: "bg-primary/15 text-primary",
  project: "bg-yellow-500/15 text-yellow-500",
  practice: "bg-purple-500/15 text-purple-400",
  prep: "bg-purple-500/15 text-purple-400",
};

const RoadmapPage = () => {
  const location = useLocation();
  const stateData = location.state as any;
  const analysisFromState: AnalysisResult | undefined = stateData?.analysis;
  const customRole = stateData?.targetRole || "Data Scientist";

  // Build analysis if not passed from dashboard
  const analysis: AnalysisResult = analysisFromState || (() => {
    const mock = getAnalysisForRole(customRole);
    return {
      targetRole: mock.targetRole,
      readinessScore: mock.readinessScore,
      detectedSkills: mock.detectedSkills,
      missingSkills: mock.missingSkills,
      roleComparison: mock.roleComparison,
      extractedText: "",
    };
  })();

  const [duration, setDuration] = useState<"4-week" | "8-week">("8-week");
  const [roadmap, setRoadmap] = useState<GeneratedRoadmap>(() =>
    generateLocalRoadmap(analysis, "8-week")
  );
  const [completedTasks, setCompletedTasks] = useState<Set<string>>(new Set());

  const handleDurationChange = (d: "4-week" | "8-week") => {
    setDuration(d);
    setRoadmap(generateLocalRoadmap(analysis, d));
    setCompletedTasks(new Set());
  };

  const toggleTask = (weekIndex: number, taskIndex: number) => {
    const key = `${weekIndex}-${taskIndex}`;
    setCompletedTasks((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const totalTasks = roadmap.weeks.reduce((sum, w) => sum + w.tasks.length, 0);
  const completedCount = completedTasks.size;
  const progressPct = totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0;

  const handleDownloadPDF = () => {
    downloadRoadmapPDF(analysis, roadmap);
  };

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">Your Learning Roadmap</h1>
          <p className="text-muted-foreground">
            Personalized plan to become a{" "}
            <span className="text-foreground font-medium">{analysis.targetRole}</span>
          </p>
        </motion.div>

        {/* Controls */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="flex flex-wrap items-center gap-4 mb-8"
        >
          <div className="flex rounded-xl border border-border overflow-hidden">
            <button
              onClick={() => handleDurationChange("4-week")}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                duration === "4-week"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary/50 text-muted-foreground hover:text-foreground"
              }`}
            >
              4 Weeks
            </button>
            <button
              onClick={() => handleDurationChange("8-week")}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                duration === "8-week"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary/50 text-muted-foreground hover:text-foreground"
              }`}
            >
              8 Weeks
            </button>
          </div>

          <Button
            variant="outline"
            onClick={handleDownloadPDF}
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            Download PDF
          </Button>
        </motion.div>

        {/* Progress Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-2xl p-6 bg-gradient-card border border-border/50 shadow-card mb-8"
        >
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Progress</h3>
            <span className="text-sm text-muted-foreground">
              {completedCount}/{totalTasks} tasks ({progressPct}%)
            </span>
          </div>
          <div className="h-3 rounded-full bg-secondary overflow-hidden">
            <motion.div
              className="h-full rounded-full bg-gradient-primary"
              initial={{ width: 0 }}
              animate={{ width: `${progressPct}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </motion.div>

        {/* Recommended Tech */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="rounded-2xl p-6 bg-gradient-card border border-border/50 shadow-card mb-8"
        >
          <h3 className="font-semibold text-foreground mb-3">Technologies to Learn</h3>
          <div className="flex flex-wrap gap-2">
            {roadmap.recommendedTech.map((tech) => (
              <span
                key={tech}
                className="px-3 py-1.5 rounded-full text-xs font-medium bg-primary/15 text-primary"
              >
                {tech}
              </span>
            ))}
          </div>
        </motion.div>

        {/* Weekly Roadmap */}
        <div className="relative">
          <div className="absolute left-6 top-0 bottom-0 w-px bg-border hidden sm:block" />

          {roadmap.weeks.map((week, wi) => {
            const Icon = phaseIcons[wi % phaseIcons.length];
            const weekCompleted = week.tasks.every((_, ti) =>
              completedTasks.has(`${wi}-${ti}`)
            );

            return (
              <motion.div
                key={`${duration}-${wi}`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: wi * 0.08 }}
                className="relative mb-10 sm:pl-16"
              >
                {/* Timeline dot */}
                <div
                  className={`absolute left-3 top-1 w-7 h-7 rounded-full border-2 flex items-center justify-center hidden sm:flex transition-colors ${
                    weekCompleted
                      ? "bg-primary border-primary"
                      : "bg-primary/20 border-primary"
                  }`}
                >
                  {weekCompleted ? (
                    <CheckCircle2 className="h-3.5 w-3.5 text-primary-foreground" />
                  ) : (
                    <Icon className="h-3.5 w-3.5 text-primary" />
                  )}
                </div>

                <div className="flex items-center gap-3 mb-4">
                  <h3 className="text-lg font-bold text-foreground">
                    Week {week.week}: {week.title}
                  </h3>
                  {weekCompleted && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-primary/20 text-primary font-medium">
                      Complete
                    </span>
                  )}
                </div>

                <div className="space-y-3">
                  {week.tasks.map((task, ti) => {
                    const isCompleted = completedTasks.has(`${wi}-${ti}`);
                    return (
                      <div
                        key={ti}
                        onClick={() => toggleTask(wi, ti)}
                        className={`rounded-xl p-4 bg-gradient-card border shadow-card flex items-start justify-between gap-4 cursor-pointer transition-all ${
                          isCompleted
                            ? "border-primary/30 opacity-70"
                            : "border-border/50 hover:border-primary/30"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          {isCompleted ? (
                            <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                          ) : (
                            <Circle className="h-5 w-5 text-muted-foreground mt-0.5 shrink-0" />
                          )}
                          <div>
                            <p
                              className={`font-medium ${
                                isCompleted ? "line-through text-muted-foreground" : "text-foreground"
                              }`}
                            >
                              {task.title}
                            </p>
                            <a
                              href={task.resourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="text-sm text-primary hover:underline mt-1 flex items-center gap-1.5"
                            >
                              <ExternalLink className="h-3 w-3" />
                              {task.resource}
                            </a>
                          </div>
                        </div>
                        <span
                          className={`text-xs px-2.5 py-1 rounded-full font-medium whitespace-nowrap ${
                            typeColors[task.type] || typeColors.course
                          }`}
                        >
                          {task.type}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Milestone */}
                <div className="mt-3 flex items-center gap-2 text-sm">
                  <Target className="h-4 w-4 text-primary" />
                  <span className="text-muted-foreground">
                    <span className="font-medium text-foreground">Milestone:</span>{" "}
                    {week.milestone}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Suggested Projects */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="rounded-2xl p-6 bg-gradient-card border border-border/50 shadow-card mt-8"
        >
          <h3 className="font-semibold text-foreground mb-4">Suggested Portfolio Projects</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            {roadmap.suggestedProjects.map((project, i) => (
              <div
                key={i}
                className="rounded-xl border border-border/50 p-4 bg-secondary/20 hover:border-primary/30 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <Rocket className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <p className="text-sm font-medium text-foreground">{project}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default RoadmapPage;

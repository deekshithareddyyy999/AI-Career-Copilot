import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "react-router-dom";
import {
  BookOpen,
  Layers,
  Rocket,
  CheckCircle2,
  Circle,
  ExternalLink,
  GraduationCap,
  Zap,
  Trophy,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  LEARNING_PATHS,
  ROLE_OPTIONS,
  type DifficultyLevel,
  type PaceLevel,
} from "@/lib/learningPathData";

const PACE_OPTIONS: { value: PaceLevel; label: string; description: string; icon: typeof Zap; price: string }[] = [
  { value: "basic", label: "Basic", description: "Take it slow, build strong foundations", icon: BookOpen, price: "Free" },
  { value: "medium", label: "Medium", description: "Balanced pace with steady progress", icon: Zap, price: "₹600" },
  { value: "advanced", label: "Advanced", description: "Accelerated learning for fast learners", icon: Rocket, price: "₹1000" },
];

const LEVEL_CONFIG: Record<DifficultyLevel, { label: string; icon: typeof BookOpen; gradient: string; accent: string }> = {
  beginner: { label: "Beginner", icon: BookOpen, gradient: "from-emerald-500/20 to-emerald-600/5", accent: "text-emerald-400" },
  intermediate: { label: "Intermediate", icon: Layers, gradient: "from-amber-500/20 to-amber-600/5", accent: "text-amber-400" },
  advanced: { label: "Advanced", icon: Trophy, gradient: "from-rose-500/20 to-rose-600/5", accent: "text-rose-400" },
};

const LearningPathPage = () => {
  const location = useLocation();
  const stateData = location.state as any;
  const detectedSkills: string[] = stateData?.detectedSkills || [];

  const [selectedRole, setSelectedRole] = useState<string>("");
  const [selectedPace, setSelectedPace] = useState<PaceLevel>("medium");
  const [completedSkills, setCompletedSkills] = useState<Set<string>>(new Set());

  const roleSkills = selectedRole ? LEARNING_PATHS[selectedRole] : null;

  // Mark detected skills as already known
  const knownSkillNames = useMemo(() => {
    return new Set(detectedSkills.map((s) => s.toLowerCase()));
  }, [detectedSkills]);

  const isKnown = (skillName: string) =>
    knownSkillNames.has(skillName.toLowerCase());

  const toggleSkill = (level: DifficultyLevel, index: number) => {
    const key = `${level}-${index}`;
    setCompletedSkills((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  const getLevelProgress = (level: DifficultyLevel) => {
    if (!roleSkills) return 0;
    const skills = roleSkills[level];
    const completed = skills.filter(
      (_, i) => completedSkills.has(`${level}-${i}`) || isKnown(skills[i].name)
    ).length;
    return Math.round((completed / skills.length) * 100);
  };

  const visibleLevels: DifficultyLevel[] =
    selectedPace === "basic"
      ? ["beginner"]
      : selectedPace === "medium"
      ? ["beginner", "intermediate"]
      : ["beginner", "intermediate", "advanced"];

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <div className="flex items-center gap-3 mb-2">
            <GraduationCap className="h-8 w-8 text-primary" />
            <h1 className="text-3xl sm:text-4xl font-bold text-foreground">Learning Path</h1>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Choose your career path and learning pace. Track your progress as you master each skill level.
          </p>
        </motion.div>

        {/* Pace Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="mb-8"
        >
          <h2 className="text-lg font-semibold text-foreground mb-3">Choose Your Pace</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {PACE_OPTIONS.map((pace) => {
              const Icon = pace.icon;
              const isSelected = selectedPace === pace.value;
              return (
                <button
                  key={pace.value}
                  onClick={() => setSelectedPace(pace.value)}
                  className={`rounded-xl p-4 border text-left transition-all ${
                    isSelected
                      ? "border-primary bg-primary/10 shadow-glow"
                      : "border-border bg-card hover:border-primary/30"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <Icon className={`h-4 w-4 ${isSelected ? "text-primary" : "text-muted-foreground"}`} />
                      <span className={`font-semibold text-sm ${isSelected ? "text-primary" : "text-foreground"}`}>
                        {pace.label}
                      </span>
                    </div>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                      pace.price === "Free"
                        ? "bg-emerald-500/20 text-emerald-400"
                        : "bg-amber-500/20 text-amber-400"
                    }`}>
                      {pace.price}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">{pace.description}</p>
                </button>
              );
            })}
          </div>
        </motion.div>

        {/* Role Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-10"
        >
          <h2 className="text-lg font-semibold text-foreground mb-3">Choose Your Career Path</h2>
          <div className="flex flex-wrap gap-2">
            {ROLE_OPTIONS.map((role) => (
              <button
                key={role}
                onClick={() => {
                  setSelectedRole(role);
                  setCompletedSkills(new Set());
                }}
                className={`px-4 py-2.5 rounded-xl text-sm font-medium border transition-all ${
                  selectedRole === role
                    ? "border-primary bg-primary/10 text-primary shadow-glow"
                    : "border-border bg-card text-muted-foreground hover:text-foreground hover:border-primary/30"
                }`}
              >
                {role}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Skills Grid */}
        <AnimatePresence mode="wait">
          {roleSkills && (
            <motion.div
              key={selectedRole + selectedPace}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className={`grid gap-6 ${
                visibleLevels.length === 1
                  ? "grid-cols-1 max-w-xl mx-auto"
                  : visibleLevels.length === 2
                  ? "grid-cols-1 md:grid-cols-2"
                  : "grid-cols-1 md:grid-cols-3"
              }`}
            >
              {visibleLevels.map((level) => {
                const config = LEVEL_CONFIG[level];
                const Icon = config.icon;
                const skills = roleSkills[level];
                const progress = getLevelProgress(level);

                return (
                  <motion.div
                    key={level}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`rounded-2xl border border-border/50 bg-gradient-to-b ${config.gradient} backdrop-blur-sm overflow-hidden`}
                  >
                    {/* Level Header */}
                    <div className="p-5 border-b border-border/30">
                      <div className="flex items-center gap-2 mb-3">
                        <Icon className={`h-5 w-5 ${config.accent}`} />
                        <h3 className={`text-lg font-bold ${config.accent}`}>{config.label}</h3>
                      </div>
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Progress</span>
                          <span>{progress}%</span>
                        </div>
                        <Progress value={progress} className="h-2" />
                      </div>
                    </div>

                    {/* Skill List */}
                    <div className="p-4 space-y-2">
                      {skills.map((skill, i) => {
                        const key = `${level}-${i}`;
                        const isCompleted = completedSkills.has(key) || isKnown(skill.name);
                        const isFromResume = isKnown(skill.name);

                        return (
                          <div
                            key={i}
                            onClick={() => !isFromResume && toggleSkill(level, i)}
                            className={`rounded-xl p-3 border transition-all ${
                              isFromResume
                                ? "border-primary/40 bg-primary/5 cursor-default"
                                : isCompleted
                                ? "border-primary/30 bg-primary/5 cursor-pointer"
                                : "border-border/30 bg-card/50 hover:border-primary/20 cursor-pointer"
                            }`}
                          >
                            <div className="flex items-start gap-2.5">
                              {isCompleted ? (
                                <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                              ) : (
                                <Circle className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                              )}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  <p
                                    className={`text-sm font-medium ${
                                      isCompleted ? "line-through text-muted-foreground" : "text-foreground"
                                    }`}
                                  >
                                    {skill.name}
                                  </p>
                                  {isFromResume && (
                                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/20 text-primary font-medium whitespace-nowrap">
                                      From Resume
                                    </span>
                                  )}
                                </div>
                                <p className="text-xs text-muted-foreground mt-0.5">{skill.description}</p>
                                {skill.resourceUrl && (
                                  <a
                                    href={skill.resourceUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    onClick={(e) => e.stopPropagation()}
                                    className="text-xs text-primary hover:underline mt-1 inline-flex items-center gap-1"
                                  >
                                    <ExternalLink className="h-3 w-3" />
                                    {skill.resource}
                                  </a>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Empty State */}
        {!selectedRole && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <GraduationCap className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground text-lg">Select a career path above to see your learning roadmap</p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default LearningPathPage;

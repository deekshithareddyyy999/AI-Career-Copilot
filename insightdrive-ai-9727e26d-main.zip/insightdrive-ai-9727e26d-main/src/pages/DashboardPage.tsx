import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from "recharts";
import SkillCard from "@/components/SkillCard";
import ScoreGauge from "@/components/ScoreGauge";
import AICareerAdvice from "@/components/AICareerAdvice";
import { getAnalysisForRole } from "@/lib/mockData";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import type { AnalysisResult } from "@/lib/skillAnalysis";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const DashboardPage = () => {
  const location = useLocation();
  const { user } = useAuth();
  const stateData = location.state as any;
  const savedRef = useRef(false);

  // Use real analysis if available, otherwise fall back to mock
  const analysisFromState: AnalysisResult | undefined = stateData?.analysis;
  const customRole = stateData?.targetRole || "Data Scientist";

  const mockFallback = getAnalysisForRole(customRole);

  // Save analysis results to database
  useEffect(() => {
    if (!analysisFromState || !user || savedRef.current) return;
    savedRef.current = true;

    const save = async () => {
      try {
        await supabase.from("analysis_results").insert({
          user_id: user.id,
          target_role: analysisFromState.targetRole,
          readiness_score: analysisFromState.readinessScore,
          detected_skills: analysisFromState.detectedSkills as any,
          missing_skills: analysisFromState.missingSkills as any,
          role_comparison: analysisFromState.roleComparison as any,
        });
      } catch (err) {
        console.error("Failed to save analysis:", err);
      }
    };
    save();
  }, [analysisFromState, user]);

  const detectedSkills = analysisFromState?.detectedSkills || mockFallback.detectedSkills;
  const missingSkills = analysisFromState?.missingSkills || mockFallback.missingSkills;
  const roleComparison = analysisFromState?.roleComparison || mockFallback.roleComparison;
  const readinessScore = analysisFromState?.readinessScore ?? mockFallback.readinessScore;
  const targetRole = analysisFromState?.targetRole || mockFallback.targetRole;

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10"
        >
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">Analysis Dashboard</h1>
          <p className="text-muted-foreground">
            Career readiness analysis for <span className="text-foreground font-medium">{targetRole}</span>
            {analysisFromState && (
              <span className="ml-2 text-xs px-2 py-0.5 rounded-full bg-primary/20 text-primary font-medium">
                Live Analysis
              </span>
            )}
          </p>
        </motion.div>

        {/* Score + Chart Row */}
        <div className="grid lg:grid-cols-3 gap-6 mb-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="rounded-2xl p-6 bg-gradient-card border border-border/50 shadow-card flex items-center justify-center"
          >
            <ScoreGauge score={readinessScore} label="Career Readiness" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2 rounded-2xl p-6 bg-gradient-card border border-border/50 shadow-card"
          >
            <h3 className="font-semibold text-foreground mb-4">Role Fit Comparison</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={roleComparison} layout="vertical" barCategoryGap="20%">
                <XAxis type="number" domain={[0, 100]} tick={{ fill: "hsl(0,0%,30%)", fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="role" width={110} tick={{ fill: "hsl(0,0%,0%)", fontSize: 13 }} axisLine={false} tickLine={false} />
                <Bar dataKey="score" radius={[0, 6, 6, 0]}>
                  {roleComparison.map((entry, i) => (
                    <Cell
                      key={i}
                      fill={
                        entry.score >= 70
                          ? "hsl(174,72%,52%)"
                          : entry.score >= 50
                          ? "hsl(45,90%,55%)"
                          : "hsl(0,72%,55%)"
                      }
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Detected Skills */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mb-10"
        >
          <h2 className="text-xl font-bold mb-4">
            Detected Skills
            <span className="ml-2 text-sm font-normal text-muted-foreground">({detectedSkills.length})</span>
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {detectedSkills.map((skill) => (
              <SkillCard key={skill.name} {...skill} />
            ))}
          </div>
        </motion.div>

        {/* Missing Skills */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mb-10"
        >
          <h2 className="text-xl font-bold mb-4">
            Missing Skills
            <span className="ml-2 text-sm font-normal text-muted-foreground">({missingSkills.length})</span>
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {missingSkills.map((skill) => (
              <SkillCard key={skill.name} {...skill} />
            ))}
          </div>
        </motion.div>

        {/* Floating AI Career Advice */}
        <AICareerAdvice
          detectedSkills={detectedSkills}
          missingSkills={missingSkills}
          targetRole={targetRole}
          readinessScore={readinessScore}
        />

        {/* CTA */}
        <div className="text-center">
          <Link to="/roadmap" state={{ analysis: analysisFromState, targetRole }}>
            <Button size="lg" className="bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-opacity">
              View Learning Roadmap
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;

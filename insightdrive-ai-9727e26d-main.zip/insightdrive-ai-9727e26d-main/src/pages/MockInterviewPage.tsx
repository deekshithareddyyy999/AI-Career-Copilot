import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Loader2, MessageSquare, RefreshCw, Sparkles, Target, CheckCircle2, XCircle, ChevronLeft, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

const ROLES = [
  "Software Engineer",
  "Data Analyst",
  "Data Scientist",
  "AI Engineer",
  "ML Engineer",
  "Full Stack Developer",
  "DevOps Engineer",
  "Product Manager",
];

interface MCQ {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  difficulty: string;
  category: string;
}

const MockInterviewPage = () => {
  const [selectedRole, setSelectedRole] = useState("");
  const [questions, setQuestions] = useState<MCQ[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const generateQuiz = async () => {
    if (!selectedRole) {
      toast.error("Please select a role first.");
      return;
    }
    setLoading(true);
    setQuestions([]);
    setAnswers({});
    setSubmitted(false);
    setCurrentQ(0);

    try {
      const { data, error } = await supabase.functions.invoke("mock-interview", {
        body: { role: selectedRole },
      });
      if (error) throw error;
      if (!data.questions?.length) throw new Error("No questions generated");
      setQuestions(data.questions);
    } catch (e: any) {
      toast.error(e.message || "Failed to generate questions.");
    } finally {
      setLoading(false);
    }
  };

  const selectOption = (qIndex: number, optIndex: number) => {
    if (submitted) return;
    setAnswers((prev) => ({ ...prev, [qIndex]: optIndex }));
  };

  const score = questions.reduce((acc, q, i) => acc + (answers[i] === q.correctIndex ? 1 : 0), 0);
  const answered = Object.keys(answers).length;
  const total = questions.length;

  const diffBadge = (d: string) => {
    if (d === "Easy") return "bg-emerald-500/10 text-emerald-600 border-emerald-500/20";
    if (d === "Hard") return "bg-red-500/10 text-red-600 border-red-500/20";
    return "bg-amber-500/10 text-amber-600 border-amber-500/20";
  };

  const q = questions[currentQ];

  return (
    <div className="min-h-screen bg-background pt-24 pb-16 px-4">
      <div className="max-w-3xl mx-auto space-y-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium">
            <MessageSquare className="h-4 w-4" />
            Mock Interview
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground">AI Mock Interview — MCQs</h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            20 role-specific multiple-choice questions with instant scoring and explanations.
          </p>
        </motion.div>

        {/* Role Selection */}
        {!questions.length && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="border border-border shadow-sm">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  Select Role
                </CardTitle>
                <CardDescription>Choose the role you're preparing for</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col sm:flex-row gap-3">
                <Select value={selectedRole} onValueChange={setSelectedRole}>
                  <SelectTrigger className="sm:w-[280px]">
                    <SelectValue placeholder="Choose a role..." />
                  </SelectTrigger>
                  <SelectContent>
                    {ROLES.map((role) => (
                      <SelectItem key={role} value={role}>{role}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={generateQuiz} disabled={!selectedRole || loading}>
                  {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Sparkles className="h-4 w-4 mr-2" />}
                  {loading ? "Generating 20 MCQs..." : "Start Quiz"}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Loading */}
        {loading && (
          <Card className="border border-border">
            <CardContent className="py-16 flex flex-col items-center gap-4">
              <Loader2 className="h-10 w-10 text-primary animate-spin" />
              <p className="text-muted-foreground">Generating 20 questions for <span className="font-semibold text-foreground">{selectedRole}</span>...</p>
            </CardContent>
          </Card>
        )}

        {/* Quiz in progress */}
        {questions.length > 0 && !submitted && q && (
          <motion.div key={currentQ} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="space-y-6">
            {/* Progress bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Question {currentQ + 1} of {total}</span>
                <span>{answered} answered</span>
              </div>
              <Progress value={((currentQ + 1) / total) * 100} className="h-2" />
            </div>

            {/* Question card */}
            <Card className="border-2 border-primary/20 shadow-md">
              <CardHeader>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <CardTitle className="text-base">Q{currentQ + 1}</CardTitle>
                  <div className="flex gap-2">
                    <Badge variant="outline" className="text-xs">{q.category}</Badge>
                    <Badge variant="outline" className={`text-xs ${diffBadge(q.difficulty)}`}>{q.difficulty}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-foreground font-medium leading-relaxed">{q.question}</p>
                <div className="space-y-2">
                  {q.options.map((opt, oi) => {
                    const selected = answers[currentQ] === oi;
                    return (
                      <button
                        key={oi}
                        onClick={() => selectOption(currentQ, oi)}
                        className={cn(
                          "w-full text-left px-4 py-3 rounded-lg border transition-all text-sm",
                          selected
                            ? "border-primary bg-primary/10 text-foreground font-medium"
                            : "border-border bg-card text-foreground hover:border-primary/40 hover:bg-primary/5"
                        )}
                      >
                        <span className="font-semibold mr-2 text-muted-foreground">{String.fromCharCode(65 + oi)}.</span>
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Navigation */}
            <div className="flex items-center justify-between">
              <Button variant="outline" onClick={() => setCurrentQ((p) => Math.max(0, p - 1))} disabled={currentQ === 0}>
                <ChevronLeft className="h-4 w-4 mr-1" /> Previous
              </Button>
              {currentQ < total - 1 ? (
                <Button onClick={() => setCurrentQ((p) => Math.min(total - 1, p + 1))}>
                  Next <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              ) : (
                <Button
                  onClick={() => setSubmitted(true)}
                  disabled={answered < total}
                  className="bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold"
                >
                  Submit Quiz ({answered}/{total})
                </Button>
              )}
            </div>

            {/* Question navigator dots */}
            <div className="flex flex-wrap gap-2 justify-center">
              {questions.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentQ(i)}
                  className={cn(
                    "h-8 w-8 rounded-full text-xs font-medium transition-all border",
                    i === currentQ
                      ? "border-primary bg-primary text-primary-foreground"
                      : answers[i] !== undefined
                      ? "border-primary/40 bg-primary/10 text-foreground"
                      : "border-border bg-card text-muted-foreground hover:border-primary/30"
                  )}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Results */}
        {submitted && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            {/* Score summary */}
            <Card className="border-2 border-primary/20">
              <CardContent className="pt-8 pb-6 text-center space-y-4">
                <div className="text-5xl font-bold text-foreground">
                  {score}<span className="text-2xl text-muted-foreground font-normal">/{total}</span>
                </div>
                <Progress value={(score / total) * 100} className={`h-3 max-w-xs mx-auto ${score / total >= 0.7 ? "[&>div]:bg-emerald-500" : score / total >= 0.4 ? "[&>div]:bg-amber-500" : "[&>div]:bg-red-500"}`} />
                <p className="text-muted-foreground">
                  {score / total >= 0.8 ? "Excellent! You're well prepared." : score / total >= 0.5 ? "Good effort! Review the explanations below." : "Keep practicing — review the explanations carefully."}
                </p>
              </CardContent>
            </Card>

            {/* All questions with answers */}
            <div className="space-y-4">
              {questions.map((q, i) => {
                const correct = answers[i] === q.correctIndex;
                return (
                  <Card key={i} className={cn("border", correct ? "border-emerald-500/30" : "border-red-500/30")}>
                    <CardContent className="pt-5 space-y-3">
                      <div className="flex items-start gap-2">
                        {correct ? (
                          <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                        )}
                        <div className="space-y-2 flex-1">
                          <p className="text-sm font-medium text-foreground">
                            <span className="text-muted-foreground mr-1">Q{i + 1}.</span> {q.question}
                          </p>
                          <div className="text-sm space-y-1">
                            <p className="text-foreground">
                              <span className="text-muted-foreground">Your answer:</span>{" "}
                              <span className={correct ? "text-emerald-600 font-medium" : "text-red-600 font-medium"}>
                                {String.fromCharCode(65 + (answers[i] ?? 0))}. {q.options[answers[i] ?? 0]}
                              </span>
                            </p>
                            {!correct && (
                              <p className="text-foreground">
                                <span className="text-muted-foreground">Correct:</span>{" "}
                                <span className="text-emerald-600 font-medium">
                                  {String.fromCharCode(65 + q.correctIndex)}. {q.options[q.correctIndex]}
                                </span>
                              </p>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground bg-muted/50 rounded-md px-3 py-2">
                            {q.explanation}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="text-center">
              <Button onClick={() => { setQuestions([]); setSubmitted(false); setAnswers({}); }} variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" /> Start New Quiz
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default MockInterviewPage;

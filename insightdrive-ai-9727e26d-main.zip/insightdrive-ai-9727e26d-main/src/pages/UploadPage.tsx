import { useState, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, FileText, ArrowRight, Loader2, CheckCircle2, FileSearch, X, BookOpen, Briefcase, Code, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { parseResume } from "@/lib/resumeParser";
import { extractSkills } from "@/lib/skillExtractor";
import { analyzeSkillGap } from "@/lib/skillAnalysis";
import { validateResume } from "@/lib/resumeValidator";

const TARGET_ROLES = [
  "Data Analyst",
  "Data Scientist",
  "AI Engineer",
  "Machine Learning Engineer",
  "Data Engineer",
  "Software Engineer",
];

const SECTION_PATTERNS: { name: string; icon: React.ReactNode; keywords: string[] }[] = [
  { name: "Skills", icon: <Code className="h-3.5 w-3.5" />, keywords: ["skill", "technical skill", "technologies", "tools", "competencies", "proficiencies"] },
  { name: "Experience", icon: <Briefcase className="h-3.5 w-3.5" />, keywords: ["experience", "work experience", "employment", "work history", "professional experience"] },
  { name: "Projects", icon: <BookOpen className="h-3.5 w-3.5" />, keywords: ["project", "projects", "personal project", "academic project"] },
  { name: "Education", icon: <GraduationCap className="h-3.5 w-3.5" />, keywords: ["education", "academic", "university", "college", "degree", "certification"] },
];

function detectSections(text: string): string[] {
  const lower = text.toLowerCase();
  return SECTION_PATTERNS
    .filter((s) => s.keywords.some((kw) => lower.includes(kw)))
    .map((s) => s.name);
}

const UploadPage = () => {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [targetRole, setTargetRole] = useState("");
  const [progress, setProgress] = useState("");
  const [progressPercent, setProgressPercent] = useState(0);
  const [resumeText, setResumeText] = useState("");
  const [detectedSections, setDetectedSections] = useState<string[]>([]);
  const [pageCount, setPageCount] = useState<number | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const navigate = useNavigate();

  const handleFile = async (f: File) => {
    const validTypes = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];
    if (!validTypes.includes(f.type)) {
      toast.error("Please upload a PDF or DOCX file.");
      return;
    }
    setFile(f);
    setIsParsing(true);
    setResumeText("");
    setDetectedSections([]);
    setPageCount(null);

    try {
      const result = await parseResume(f);
      const { text, pageCount: pages } = result;

      // Reject resumes longer than 2 pages
      if (pages > 2) {
        toast.error("Resume must be 2 pages or less. Please shorten your resume and try again.");
        setFile(null);
        setIsParsing(false);
        return;
      }

      // Validate that this is actually a resume
      const validation = validateResume(text);
      if (!validation.valid) {
        toast.error(validation.reason);
        setFile(null);
        setIsParsing(false);
        return;
      }

      setResumeText(text);
      setDetectedSections(detectSections(text));
      setPageCount(pages);

      toast.success(`"${f.name}" uploaded successfully.`);
    } catch {
      toast.error("Could not parse resume. Please try a different file.");
      setFile(null);
    } finally {
      setIsParsing(false);
    }
  };

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  }, []);

  const handleAnalyze = async () => {
    if (!file || !resumeText) return;
    if (!targetRole) {
      toast.error("Please select your target job title.");
      return;
    }
    setIsAnalyzing(true);
    setProgressPercent(0);

    try {
      setProgress("Extracting skills...");
      setProgressPercent(25);
      const extractedSkills = extractSkills(resumeText);

      setProgress("Analyzing skill gaps...");
      setProgressPercent(55);
      await new Promise((r) => setTimeout(r, 500));
      const analysis = analyzeSkillGap(extractedSkills, targetRole, resumeText);

      setProgress("Generating results...");
      setProgressPercent(85);
      await new Promise((r) => setTimeout(r, 400));
      setProgressPercent(100);
      await new Promise((r) => setTimeout(r, 200));

      toast.success(`Found ${analysis.detectedSkills.length} skills, ${analysis.missingSkills.length} gaps identified.`);
      navigate("/dashboard", { state: { analysis } });
    } catch (err) {
      console.error("Analysis error:", err);
      toast.error("Failed to analyze resume. Please try again.");
    } finally {
      setIsAnalyzing(false);
      setProgress("");
      setProgressPercent(0);
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <h1 className="text-3xl sm:text-4xl font-bold mb-3">Upload Your Resume</h1>
          <p className="text-muted-foreground">
            We'll parse your resume, extract skills, and analyze career readiness — all in your browser.
          </p>
        </motion.div>

        {/* Target Role Dropdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="mb-8"
        >
          <label className="block text-sm font-medium text-foreground mb-2">
            Target Job Title
          </label>
          <Select value={targetRole} onValueChange={setTargetRole}>
            <SelectTrigger className="w-full h-12 rounded-xl border-border bg-secondary/50 text-foreground focus:ring-primary/50 focus:border-primary">
              <SelectValue placeholder="Select your target role..." />
            </SelectTrigger>
            <SelectContent>
              {TARGET_ROLES.map((role) => (
                <SelectItem key={role} value={role}>
                  {role}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </motion.div>

        {/* Upload Area */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={onDrop}
          className={`relative rounded-2xl border-2 border-dashed p-12 text-center transition-all cursor-pointer group ${
            isDragging
              ? "border-primary bg-primary/10 scale-[1.02]"
              : file
              ? "border-primary/40 bg-primary/5"
              : "border-border hover:border-muted-foreground/40 hover:bg-secondary/30"
          }`}
          onClick={() => {
            if (!file) {
              const input = document.createElement("input");
              input.type = "file";
              input.accept = ".pdf,.docx";
              input.onchange = (e) => {
                const f = (e.target as HTMLInputElement).files?.[0];
                if (f) handleFile(f);
              };
              input.click();
            }
          }}
        >
          <AnimatePresence mode="wait">
            {isParsing ? (
              <motion.div
                key="parsing"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="flex flex-col items-center gap-3"
              >
                <Loader2 className="h-12 w-12 text-primary animate-spin" />
                <p className="font-semibold text-foreground">Parsing resume...</p>
              </motion.div>
            ) : file ? (
              <motion.div
                key="file-info"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="flex flex-col items-center gap-3"
              >
                <div className="relative">
                  <FileText className="h-12 w-12 text-primary" />
                  <CheckCircle2 className="h-5 w-5 text-green-500 absolute -bottom-1 -right-1" />
                </div>
                <p className="font-semibold text-foreground">{file.name}</p>
                <p className="text-sm text-muted-foreground">
                  {(file.size / 1024).toFixed(1)} KB
                </p>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setFile(null);
                    setResumeText("");
                    setDetectedSections([]);
                    setPageCount(null);
                  }}
                  className="text-xs text-destructive hover:underline mt-1 flex items-center gap-1"
                >
                  <X className="h-3 w-3" /> Remove
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="flex flex-col items-center gap-3"
              >
                <motion.div
                  animate={isDragging ? { y: -8, scale: 1.1 } : { y: 0, scale: 1 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <Upload className="h-12 w-12 text-muted-foreground group-hover:text-primary transition-colors" />
                </motion.div>
                <p className="font-semibold text-foreground">
                  Drop your resume here or click to browse
                </p>
                <p className="text-sm text-muted-foreground">PDF or DOCX, up to 10 MB</p>
                <div className="flex gap-2 mt-2">
                  <Badge variant="secondary" className="text-xs">
                    <FileText className="h-3 w-3 mr-1" /> PDF
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    <FileSearch className="h-3 w-3 mr-1" /> DOCX
                  </Badge>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Preview Card */}
        <AnimatePresence>
          {file && resumeText && !isParsing && (
            <motion.div
              initial={{ opacity: 0, y: 20, height: 0 }}
              animate={{ opacity: 1, y: 0, height: "auto" }}
              exit={{ opacity: 0, y: -10, height: 0 }}
              className="mt-6 rounded-xl border border-border bg-card p-5 space-y-4"
            >
              <div className="flex items-center gap-2 text-sm text-green-400 font-medium">
                <CheckCircle2 className="h-4 w-4" />
                Resume uploaded successfully. Ready for analysis.
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-lg bg-secondary/50 p-3">
                  <p className="text-muted-foreground text-xs mb-1">File Name</p>
                  <p className="font-medium text-foreground truncate">{file.name}</p>
                </div>
                <div className="rounded-lg bg-secondary/50 p-3">
                  <p className="text-muted-foreground text-xs mb-1">File Size</p>
                  <p className="font-medium text-foreground">{(file.size / 1024).toFixed(1)} KB</p>
                </div>
                <div className="rounded-lg bg-secondary/50 p-3">
                  <p className="text-muted-foreground text-xs mb-1">Est. Pages</p>
                  <p className="font-medium text-foreground">{pageCount ?? "—"}</p>
                </div>
                <div className="rounded-lg bg-secondary/50 p-3">
                  <p className="text-muted-foreground text-xs mb-1">Sections Found</p>
                  <p className="font-medium text-foreground">{detectedSections.length}</p>
                </div>
              </div>

              {detectedSections.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {SECTION_PATTERNS.filter((s) => detectedSections.includes(s.name)).map((s) => (
                    <Badge key={s.name} variant="outline" className="text-xs gap-1 border-primary/30 text-primary">
                      {s.icon} {s.name}
                    </Badge>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Analyze Button + Progress */}
        {file && resumeText && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 space-y-4"
          >
            {isAnalyzing && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{progress}</span>
                  <span>{progressPercent}%</span>
                </div>
                <Progress value={progressPercent} className="h-2" />
              </div>
            )}
            <div className="text-center">
              <Button
                size="lg"
                onClick={handleAnalyze}
                disabled={isAnalyzing}
                className="bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-opacity text-base px-8"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    Analyze Resume
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default UploadPage;

import { motion } from "framer-motion";
import { Brain, Target, Users, Zap } from "lucide-react";

const values = [
  { icon: Brain, title: "AI-First", description: "We leverage cutting-edge language models to deliver accurate career insights." },
  { icon: Target, title: "Personalized", description: "Every recommendation is tailored to your unique skill profile and career goals." },
  { icon: Users, title: "For Everyone", description: "Built for students, career changers, and professionals at every stage." },
  { icon: Zap, title: "Actionable", description: "No fluff — just clear steps and resources to close your skill gaps fast." },
];

const AboutPage = () => {
  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-3xl sm:text-4xl font-bold mb-4">About AI Career Copilot</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed text-lg">
            We're on a mission to democratize career intelligence. By combining AI-powered resume analysis with curated learning resources, we help you understand where you stand — and exactly how to get where you want to go.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 gap-6 mb-16">
          {values.map((v, i) => (
            <motion.div
              key={v.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="rounded-2xl p-6 bg-gradient-card border border-border/50 shadow-card"
            >
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <v.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">{v.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{v.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="text-muted-foreground">
            Built with ❤️ using React, Tailwind CSS, and AI.
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default AboutPage;

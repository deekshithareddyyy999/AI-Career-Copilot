import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  TrendingUp,
  BarChart3,
  Flame,
  Sparkles,
  Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  JOB_MARKET_DATA,
  DEMAND_LEVEL_CONFIG,
  type DemandLevel,
} from "@/lib/jobMarketData";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const ROLES = Object.keys(JOB_MARKET_DATA);

const LEVEL_ICONS: Record<DemandLevel, typeof Flame> = {
  high: Flame,
  moderate: Zap,
  emerging: Sparkles,
};

const BAR_COLORS: Record<DemandLevel, string> = {
  high: "#34d399",
  moderate: "#fbbf24",
  emerging: "#a78bfa",
};

const JobMarketPage = () => {
  const [selectedRole, setSelectedRole] = useState<string>("");

  const skills = selectedRole ? JOB_MARKET_DATA[selectedRole] : null;

  const groupedSkills = useMemo(() => {
    if (!skills) return null;
    return {
      high: skills.filter((s) => s.level === "high"),
      moderate: skills.filter((s) => s.level === "moderate"),
      emerging: skills.filter((s) => s.level === "emerging"),
    };
  }, [skills]);

  const chartData = useMemo(() => {
    if (!skills) return [];
    return skills
      .sort((a, b) => b.growthPercent - a.growthPercent)
      .map((s) => ({
        name: s.name.length > 14 ? s.name.slice(0, 12) + "…" : s.name,
        fullName: s.name,
        growth: s.growthPercent,
        level: s.level,
      }));
  }, [skills]);

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <div className="flex items-center gap-3 mb-2">
            <BarChart3 className="h-8 w-8 text-primary" />
            <h1 className="text-3xl sm:text-4xl font-bold text-foreground">
              Job Market Demand Analyzer
            </h1>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Discover which skills are most in-demand for your target career role. Stay ahead by focusing on high-growth technologies.
          </p>
        </motion.div>

        {/* Role Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="mb-10"
        >
          <h2 className="text-lg font-semibold text-foreground mb-3">Select a Career Role</h2>
          <div className="flex flex-wrap gap-2">
            {ROLES.map((role) => (
              <button
                key={role}
                onClick={() => setSelectedRole(role)}
                className={`px-4 py-2.5 rounded-xl text-sm font-medium border transition-all ${
                  selectedRole === role
                    ? "border-primary bg-primary/10 text-primary shadow-glow"
                    : "border-border bg-card text-muted-foreground hover:text-foreground hover:border-primary/30"
                }`}
              >
                {role}
              </button>
            ))}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {groupedSkills && skills && (
            <motion.div
              key={selectedRole}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-10"
            >
              {/* Chart */}
              <div className="rounded-2xl border border-border/50 bg-card p-6">
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-bold text-foreground">
                    YoY Growth by Skill
                  </h3>
                </div>
                <div className="h-[320px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} layout="vertical" margin={{ left: 10, right: 30, top: 5, bottom: 5 }}>
                      <XAxis
                        type="number"
                        tick={{ fill: "hsl(0,0%,45%)", fontSize: 12 }}
                        tickFormatter={(v) => `${v}%`}
                      />
                      <YAxis
                        dataKey="name"
                        type="category"
                        width={120}
                        tick={{ fill: "hsl(0,0%,30%)", fontSize: 12 }}
                      />
                      <Tooltip
                        formatter={(value: number, _: any, entry: any) => [
                          `${value}% YoY growth`,
                          entry.payload.fullName,
                        ]}
                        contentStyle={{
                          background: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px",
                          color: "hsl(var(--foreground))",
                        }}
                      />
                      <Bar dataKey="growth" radius={[0, 6, 6, 0]} barSize={20}>
                        {chartData.map((entry, index) => (
                          <Cell key={index} fill={BAR_COLORS[entry.level]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                {/* Legend */}
                <div className="flex flex-wrap gap-4 mt-4 justify-center">
                  {(["high", "moderate", "emerging"] as DemandLevel[]).map((level) => {
                    const config = DEMAND_LEVEL_CONFIG[level];
                    return (
                      <div key={level} className="flex items-center gap-1.5 text-xs">
                        <span
                          className="w-3 h-3 rounded-sm"
                          style={{ backgroundColor: BAR_COLORS[level] }}
                        />
                        <span className="text-muted-foreground">{config.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Skill Categories */}
              <div className="grid gap-6 md:grid-cols-3">
                {(["high", "moderate", "emerging"] as DemandLevel[]).map((level) => {
                  const config = DEMAND_LEVEL_CONFIG[level];
                  const Icon = LEVEL_ICONS[level];
                  const levelSkills = groupedSkills[level];

                  return (
                    <motion.div
                      key={level}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`rounded-2xl border ${config.borderColor} ${config.bgColor} p-5`}
                    >
                      <div className="flex items-center gap-2 mb-4">
                        <Icon className={`h-5 w-5 ${config.color}`} />
                        <h3 className={`text-lg font-bold ${config.color}`}>
                          {config.label}
                        </h3>
                      </div>
                      <div className="space-y-3">
                        {levelSkills.map((skill) => (
                          <div
                            key={skill.name}
                            className="rounded-xl border border-border/30 bg-card/60 p-3 transition-all hover:scale-[1.02]"
                          >
                            <div className="flex items-center justify-between mb-1">
                              <p className="text-sm font-semibold text-foreground">
                                {skill.name}
                              </p>
                              <Badge
                                variant="outline"
                                className={`text-[10px] ${config.color} border-current`}
                              >
                                +{skill.growthPercent}%
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {skill.description}
                            </p>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Empty State */}
        {!selectedRole && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <BarChart3 className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground text-lg">
              Select a career role above to explore in-demand skills
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default JobMarketPage;

# AI Career Copilot — Python Backend Specification

This document provides a complete specification for building a Python (FastAPI) backend
to complement the React frontend. Use this to set up a local development environment.

---

## Project Structure

```
backend/
├── main.py                  # FastAPI entry point
├── requirements.txt         # Python dependencies
├── .env                     # Environment variables (API keys)
├── resume_parser/
│   ├── __init__.py
│   └── parser.py            # PDF/DOCX text extraction
├── skill_analysis/
│   ├── __init__.py
│   ├── extractor.py         # Skill extraction from text
│   ├── analyzer.py          # Gap analysis + scoring
│   └── role_requirements.py # Predefined role skill lists
├── ai_engine/
│   ├── __init__.py
│   └── roadmap_generator.py # LLM-powered roadmap generation
└── uploads/                 # Local file storage during dev
```

---

## Setup & Run

```bash
# 1. Create virtual environment
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set environment variables
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY or GEMINI_API_KEY

# 4. Run the server
uvicorn main:app --reload --port 8000
```

---

## requirements.txt

```
fastapi==0.104.1
uvicorn==0.24.0
python-multipart==0.0.6
pdfplumber==0.10.3
python-docx==1.1.0
openai==1.6.1
google-generativeai==0.3.2
pydantic==2.5.3
python-dotenv==1.0.0
```

---

## API Endpoints

### POST /api/upload
Upload a resume file (PDF or DOCX).

**Request**: `multipart/form-data` with `file` field
**Response**:
```json
{
  "filename": "resume.pdf",
  "text": "extracted text content...",
  "word_count": 450
}
```

### POST /api/analyze
Analyze extracted resume text against a target role.

**Request**:
```json
{
  "resume_text": "...",
  "target_role": "Data Scientist"
}
```

**Response**:
```json
{
  "target_role": "Data Scientist",
  "readiness_score": 68,
  "detected_skills": [
    { "name": "Python", "level": "strong", "category": "Programming" }
  ],
  "missing_skills": [
    { "name": "Deep Learning", "level": "missing", "category": "ML" }
  ],
  "role_comparison": [
    { "role": "Data Analyst", "score": 85 },
    { "role": "Data Scientist", "score": 68 }
  ]
}
```

### POST /api/roadmap
Generate an AI-powered learning roadmap.

**Request**:
```json
{
  "target_role": "Data Scientist",
  "detected_skills": ["Python", "SQL", "Pandas"],
  "missing_skills": ["Deep Learning", "TensorFlow", "NLP"],
  "duration": "8-week"
}
```

**Response**:
```json
{
  "duration": "8-week",
  "weeks": [
    {
      "week": 1,
      "title": "Deep Learning Foundations",
      "tasks": [
        {
          "title": "Complete Deep Learning Specialization",
          "resource": "Coursera",
          "type": "course"
        }
      ],
      "milestone": "Understand neural network fundamentals"
    }
  ],
  "recommended_tech": ["TensorFlow", "PyTorch"],
  "suggested_projects": ["Build an image classifier"]
}
```

---

## main.py

```python
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
import os

from resume_parser.parser import extract_text
from skill_analysis.extractor import extract_skills
from skill_analysis.analyzer import analyze_gap
from ai_engine.roadmap_generator import generate_roadmap

load_dotenv()

app = FastAPI(title="AI Career Copilot API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)


@app.post("/api/upload")
async def upload_resume(file: UploadFile = File(...)):
    if file.content_type not in [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ]:
        raise HTTPException(400, "Only PDF and DOCX files are supported")

    filepath = os.path.join(UPLOAD_DIR, file.filename)
    with open(filepath, "wb") as f:
        content = await file.read()
        f.write(content)

    text = extract_text(filepath)
    return {"filename": file.filename, "text": text, "word_count": len(text.split())}


class AnalyzeRequest(BaseModel):
    resume_text: str
    target_role: str


@app.post("/api/analyze")
async def analyze_resume(req: AnalyzeRequest):
    skills = extract_skills(req.resume_text)
    result = analyze_gap(skills, req.target_role)
    return result


class RoadmapRequest(BaseModel):
    target_role: str
    detected_skills: list[str]
    missing_skills: list[str]
    duration: str = "8-week"


@app.post("/api/roadmap")
async def get_roadmap(req: RoadmapRequest):
    roadmap = await generate_roadmap(
        req.target_role, req.detected_skills, req.missing_skills, req.duration
    )
    return roadmap
```

---

## resume_parser/parser.py

```python
import pdfplumber
from docx import Document


def extract_text(filepath: str) -> str:
    if filepath.endswith(".pdf"):
        return _parse_pdf(filepath)
    elif filepath.endswith(".docx"):
        return _parse_docx(filepath)
    raise ValueError("Unsupported file format")


def _parse_pdf(filepath: str) -> str:
    text_parts = []
    with pdfplumber.open(filepath) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                text_parts.append(text)
    return " ".join(text_parts)


def _parse_docx(filepath: str) -> str:
    doc = Document(filepath)
    return " ".join([p.text for p in doc.paragraphs if p.text.strip()])
```

---

## ai_engine/roadmap_generator.py

```python
import os
import json
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


async def generate_roadmap(
    target_role: str,
    detected_skills: list[str],
    missing_skills: list[str],
    duration: str = "8-week",
) -> dict:
    prompt = f"""Generate a {duration} career learning roadmap for someone
targeting the role of {target_role}.

Their current skills: {', '.join(detected_skills)}
Skills they need to learn: {', '.join(missing_skills)}

Return a JSON object with:
- "duration": "{duration}"
- "weeks": array of week objects, each with:
  - "week": number
  - "title": string
  - "tasks": array of {{ "title", "resource", "type" }} where type is
    "course", "project", or "prep"
  - "milestone": string
- "recommended_tech": array of technology names
- "suggested_projects": array of project ideas

Return ONLY valid JSON, no markdown."""

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a career coaching AI."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.7,
    )

    return json.loads(response.choices[0].message.content)
```

---

## Connecting Frontend to Backend

To use the Python backend instead of client-side processing, update the
React frontend's UploadPage to call the API:

```typescript
// In UploadPage.tsx, replace the client-side analysis with:
const formData = new FormData();
formData.append("file", file);

const uploadRes = await fetch("http://localhost:8000/api/upload", {
  method: "POST",
  body: formData,
});
const { text } = await uploadRes.json();

const analyzeRes = await fetch("http://localhost:8000/api/analyze", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ resume_text: text, target_role: targetRole }),
});
const analysis = await analyzeRes.json();
```

---

## Environment Variables (.env)

```
OPENAI_API_KEY=sk-your-key-here
# OR
GEMINI_API_KEY=your-gemini-key-here
```

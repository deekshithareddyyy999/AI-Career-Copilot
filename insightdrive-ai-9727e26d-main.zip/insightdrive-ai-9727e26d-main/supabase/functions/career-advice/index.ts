import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { detectedSkills, missingSkills, targetRole, readinessScore } = await req.json();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const detectedList = (detectedSkills || []).map((s: any) => `${s.name} (${s.level})`).join(", ");
    const missingList = (missingSkills || []).map((s: any) => s.name).join(", ");

    const systemPrompt = `You are an expert career advisor for tech professionals. Analyze the user's resume skills and provide personalized career advice. Be specific, actionable, and encouraging. Format your response EXACTLY as JSON with this structure:
{
  "strengths": "2-3 sentences about the user's key strengths based on their detected skills",
  "weaknesses": "2-3 sentences about areas needing improvement based on missing skills",
  "nextSteps": ["step 1", "step 2", "step 3", "step 4", "step 5"]
}
Return ONLY valid JSON, no markdown or extra text.`;

    const userPrompt = `Target Role: ${targetRole}
Readiness Score: ${readinessScore}%
Detected Skills: ${detectedList}
Missing Skills: ${missingList}

Provide personalized career advice for this candidate.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        stream: false,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI service unavailable" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";

    // Parse the JSON from the AI response
    let advice;
    try {
      // Strip markdown code fences if present
      const cleaned = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      advice = JSON.parse(cleaned);
    } catch {
      advice = {
        strengths: "You have a solid foundation of technical skills relevant to your target role.",
        weaknesses: "There are some key skills missing that would strengthen your candidacy.",
        nextSteps: ["Focus on building projects", "Learn the missing technical skills", "Network with professionals in your target role"],
      };
    }

    return new Response(JSON.stringify(advice), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("career-advice error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
